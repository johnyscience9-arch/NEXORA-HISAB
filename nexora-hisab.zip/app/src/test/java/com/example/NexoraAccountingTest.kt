package com.example

import com.example.util.AppCurrency
import com.example.util.Formatters
import org.junit.Assert.*
import org.junit.Test
import java.security.MessageDigest

class NexoraAccountingTest {

    @Test
    fun testCurrencyFormatting() {
        val bdt = Formatters.formatCurrency(1250.50, AppCurrency.BDT)
        assertTrue("Expected BDT symbol ৳ in '$bdt'", bdt.contains("৳") || bdt.contains("BDT"))
        assertTrue("Expected 1,250.50 in '$bdt'", bdt.contains("1,250.50"))

        val usd = Formatters.formatCurrency(500.0, AppCurrency.USD)
        assertTrue("Expected USD symbol $ in '$usd'", usd.contains("$"))
        assertTrue("Expected 500.00 in '$usd'", usd.contains("500.00"))
    }

    @Test
    fun testProfitAndLossAccountingAccuracy() {
        // Accounting standard rule: Gross Profit = Sales - COGS, Net Profit = Gross Profit - Expenses
        val totalSales = 10000.0
        val costOfGoodsSold = 6500.0
        val operatingExpenses = 1200.0

        val grossProfit = totalSales - costOfGoodsSold
        assertEquals(3500.0, grossProfit, 0.001)

        val netProfit = grossProfit - operatingExpenses
        assertEquals(2300.0, netProfit, 0.001)

        // Make sure net profit accounts for COGS and doesn't just subtract expenses from sales
        assertNotEquals(totalSales - operatingExpenses, netProfit)
    }

    @Test
    fun testSha256PinHashing() {
        fun hashPin(pin: String): String {
            return MessageDigest.getInstance("SHA-256")
                .digest(pin.toByteArray())
                .joinToString("") { "%02x".format(it) }
        }

        val pin1 = "1234"
        val hash1 = hashPin(pin1)
        val hash2 = hashPin("1234")
        val hashWrong = hashPin("4321")

        assertEquals(hash1, hash2)
        assertNotEquals(hash1, hashWrong)
        assertEquals(64, hash1.length) // 256 bits = 64 hex characters
    }

    @Test
    fun testDateFilterIntervals() {
        val now = System.currentTimeMillis()
        val startOfDay = Formatters.getStartOfDay(now)
        val startOfWeek = Formatters.getStartOfWeek(now)
        val startOfMonth = Formatters.getStartOfMonth(now)
        val startOfYear = Formatters.getStartOfYear(now)

        assertTrue(startOfDay <= now)
        assertTrue(startOfWeek <= startOfDay)
        assertTrue(startOfMonth <= now)
        assertTrue(startOfYear <= startOfMonth)
    }
}
