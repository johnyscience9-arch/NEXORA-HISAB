package com.example

import com.example.util.AppCurrency
import com.example.util.AppLanguage
import com.example.util.Localization
import org.junit.Assert.assertEquals
import org.junit.Test

class NexoraLocalizationUnitTest {

  @Test
  fun testAppNameAndLocalization() {
    val bnTitle = Localization.getString("app_title", AppLanguage.BENGALI)
    val enTitle = Localization.getString("app_title", AppLanguage.ENGLISH)

    assertEquals("নেক্সোরা হিসাব", bnTitle)
    assertEquals("NEXORA HISAB", enTitle)
  }

  @Test
  fun testCurrencySymbols() {
    assertEquals("৳", AppCurrency.BDT.symbol)
    assertEquals("$", AppCurrency.USD.symbol)
  }
}
