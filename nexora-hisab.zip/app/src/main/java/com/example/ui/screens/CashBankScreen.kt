package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Account
import com.example.ui.components.EmptyStateView
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.NexoraViewModel
import com.example.util.AppCurrency
import com.example.util.AppLanguage
import com.example.util.Formatters
import com.example.util.Localization

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CashBankScreen(
    viewModel: NexoraViewModel,
    currency: AppCurrency,
    language: AppLanguage
) {
    val accounts by viewModel.accounts.collectAsState()
    val transactions by viewModel.recentTransactions.collectAsState()

    val cashAccounts = remember(accounts) { accounts.filter { it.accountType == "CASH" } }
    val bankAccounts = remember(accounts) { accounts.filter { it.accountType == "BANK" } }

    val totalCashBalance = remember(cashAccounts) { cashAccounts.sumOf { it.balance } }
    val totalBankBalance = remember(bankAccounts) { bankAccounts.sumOf { it.balance } }

    var showTransferDialog by remember { mutableStateOf(false) }
    var isDepositMode by remember { mutableStateOf(true) } // true = Deposit to Bank, false = Withdraw to Cash

    val context = LocalContext.current

    Scaffold(
        containerColor = NexoraDarkBackground,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NexoraDarkSurface),
                title = {
                    Text(
                        text = Localization.getString("cash_bank", language),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraTextPrimary
                        )
                    )
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Account Balances Card (Cash & Bank)
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    AccountBalanceCard(
                        title = Localization.getString("cash_account", language),
                        balance = totalCashBalance,
                        currency = currency,
                        icon = Icons.Default.Payments,
                        color = NexoraEmeraldSuccess,
                        modifier = Modifier.weight(1f)
                    )
                    AccountBalanceCard(
                        title = Localization.getString("bank_account", language),
                        balance = totalBankBalance,
                        currency = currency,
                        icon = Icons.Default.AccountBalance,
                        color = NexoraCyanPrimary,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // 2. Transfer Actions Row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            isDepositMode = true
                            showTransferDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NexoraDarkSurface),
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraCyanPrimary)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("deposit_cash_button")
                    ) {
                        Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = NexoraCyanPrimary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(Localization.getString("deposit", language), color = NexoraCyanPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            isDepositMode = false
                            showTransferDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NexoraDarkSurface),
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraGoldAmber)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("withdraw_cash_button")
                    ) {
                        Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = NexoraGoldAmber, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(Localization.getString("withdrawal", language), color = NexoraGoldAmber, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // 3. Transactions Ledger
            item {
                SectionHeader(title = "Account Statement & Log")
            }

            if (transactions.isEmpty()) {
                item {
                    EmptyStateView(
                        icon = Icons.Default.Receipt,
                        title = Localization.getString("no_data", language),
                        message = "No cash or bank transactions recorded yet."
                    )
                }
            } else {
                items(transactions, key = { it.id }) { tx ->
                    TransactionRowItem(tx = tx, currency = currency)
                }
            }
        }
    }

    // Deposit / Withdraw Dialog
    if (showTransferDialog) {
        var amountInput by remember { mutableStateOf("") }
        var notesInput by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showTransferDialog = false },
            containerColor = NexoraDarkSurfaceVariant,
            title = {
                Text(
                    text = if (isDepositMode) Localization.getString("deposit", language) else Localization.getString("withdrawal", language),
                    color = NexoraTextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = if (isDepositMode) "Transfer cash from hand into bank account." else "Withdraw cash from bank account to hand.",
                        color = NexoraTextSecondary,
                        fontSize = 13.sp
                    )

                    OutlinedTextField(
                        value = amountInput,
                        onValueChange = { amountInput = it },
                        label = { Text("Transfer Amount (${currency.symbol})") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = notesInput,
                        onValueChange = { notesInput = it },
                        label = { Text(Localization.getString("notes", language)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = amountInput.toDoubleOrNull() ?: 0.0
                        if (amt <= 0) return@Button

                        val cashId = cashAccounts.firstOrNull()?.id ?: 1L
                        val bankId = bankAccounts.firstOrNull()?.id ?: 2L

                        viewModel.adjustCashDepositWithdrawal(
                            isDeposit = isDepositMode,
                            amount = amt,
                            notes = notesInput
                        ) {
                            Toast.makeText(context, "Account Transfer Complete!", Toast.LENGTH_SHORT).show()
                            showTransferDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isDepositMode) NexoraCyanPrimary else NexoraGoldAmber
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("confirm_transfer_button")
                ) {
                    Text(Localization.getString("confirm", language), color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showTransferDialog = false }) {
                    Text(Localization.getString("cancel", language), color = NexoraTextSecondary)
                }
            }
        )
    }
}

@Composable
fun AccountBalanceCard(
    title: String,
    balance: Double,
    currency: AppCurrency,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = NexoraDarkSurface),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(text = title, color = NexoraTextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = Formatters.formatCurrency(balance, currency),
                color = NexoraTextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp
            )
        }
    }
}
