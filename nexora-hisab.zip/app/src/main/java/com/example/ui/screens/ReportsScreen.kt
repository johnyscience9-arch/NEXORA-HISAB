package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.NexoraViewModel
import com.example.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    viewModel: NexoraViewModel,
    currency: AppCurrency,
    language: AppLanguage
) {
    var selectedPeriodFilter by remember { mutableStateOf("ALL") } // TODAY, WEEK, MONTH, YEAR, ALL

    val sales by viewModel.sales.collectAsState()
    val purchases by viewModel.purchases.collectAsState()
    val expenses by viewModel.expenses.collectAsState()
    val customers by viewModel.customers.collectAsState()
    val suppliers by viewModel.suppliers.collectAsState()
    val products by viewModel.products.collectAsState()

    val context = LocalContext.current

    val now = System.currentTimeMillis()
    val startTime = remember(selectedPeriodFilter) {
        when (selectedPeriodFilter) {
            "TODAY" -> Formatters.getStartOfDay(now)
            "WEEK" -> Formatters.getStartOfWeek(now)
            "MONTH" -> Formatters.getStartOfMonth(now)
            "YEAR" -> Formatters.getStartOfYear(now)
            else -> 0L
        }
    }

    val activeSales = remember(sales, startTime) {
        sales.filter { it.status == "ACTIVE" && it.date >= startTime }
    }
    val filteredPurchases = remember(purchases, startTime) {
        purchases.filter { it.date >= startTime }
    }
    val filteredExpenses = remember(expenses, startTime) {
        expenses.filter { it.date >= startTime }
    }

    val totalSales = remember(activeSales) { activeSales.sumOf { it.grandTotal } }
    val totalPurchases = remember(filteredPurchases) { filteredPurchases.sumOf { it.grandTotal } }
    val totalExpenses = remember(filteredExpenses) { filteredExpenses.sumOf { it.amount } }

    val avgCostMarginRatio = remember(products) {
        if (products.isNotEmpty()) {
            val totalSell = products.sumOf { it.sellingPrice }
            val totalCost = products.sumOf { it.purchasePrice }
            if (totalSell > 0) (totalCost / totalSell).coerceIn(0.1, 0.95) else 0.75
        } else 0.75
    }

    val estimatedCogs = totalSales * avgCostMarginRatio
    val grossProfit = totalSales - estimatedCogs
    val netProfit = grossProfit - totalExpenses

    val totalCustomerDue = remember(customers) { customers.sumOf { it.currentDue } }
    val totalSupplierPayable = remember(suppliers) { suppliers.sumOf { it.currentPayable } }
    val totalStockValuation = remember(products) { products.sumOf { it.stockQuantity * it.purchasePrice } }

    Scaffold(
        containerColor = NexoraDarkBackground,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NexoraDarkSurface),
                title = {
                    Text(
                        text = Localization.getString("reports", language),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraTextPrimary
                        )
                    )
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Period Filter Chips
            item {
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 4.dp)
                ) {
                    item {
                        FilterChip(
                            selected = selectedPeriodFilter == "TODAY",
                            onClick = { selectedPeriodFilter = "TODAY" },
                            label = { Text(Localization.getString("filter_today", language)) }
                        )
                    }
                    item {
                        FilterChip(
                            selected = selectedPeriodFilter == "WEEK",
                            onClick = { selectedPeriodFilter = "WEEK" },
                            label = { Text(Localization.getString("filter_week", language)) }
                        )
                    }
                    item {
                        FilterChip(
                            selected = selectedPeriodFilter == "MONTH",
                            onClick = { selectedPeriodFilter = "MONTH" },
                            label = { Text(Localization.getString("filter_month", language)) }
                        )
                    }
                    item {
                        FilterChip(
                            selected = selectedPeriodFilter == "YEAR",
                            onClick = { selectedPeriodFilter = "YEAR" },
                            label = { Text(Localization.getString("filter_year", language)) }
                        )
                    }
                    item {
                        FilterChip(
                            selected = selectedPeriodFilter == "ALL",
                            onClick = { selectedPeriodFilter = "ALL" },
                            label = { Text(Localization.getString("filter_all", language)) }
                        )
                    }
                }
            }

            // 2. Profit and Loss Statement Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NexoraDarkSurface),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.AutoMirrored.Filled.TrendingUp, contentDescription = null, tint = NexoraCyanPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = Localization.getString("profit_and_loss", language),
                                color = NexoraTextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        ReportLineItem("Gross Revenue / Sales (+)", totalSales, NexoraTextPrimary, currency)
                        ReportLineItem("Cost of Goods Sold (COGS) (-)", estimatedCogs, NexoraCoralError, currency)
                        HorizontalDivider(color = NexoraDarkBorder, modifier = Modifier.padding(vertical = 8.dp))
                        ReportLineItem(Localization.getString("gross_profit", language), grossProfit, NexoraCyanPrimary, currency, isBold = true)
                        ReportLineItem("Operating Expenses (-)", totalExpenses, NexoraGoldAmber, currency)
                        HorizontalDivider(color = NexoraDarkBorder, modifier = Modifier.padding(vertical = 8.dp))
                        ReportLineItem(
                            Localization.getString("net_profit", language),
                            netProfit,
                            if (netProfit >= 0) NexoraEmeraldSuccess else NexoraCoralError,
                            currency,
                            isBold = true,
                            fontSize = 17.sp
                        )
                    }
                }
            }

            // 3. Operational Summary
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NexoraDarkSurface),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Ledger Balances & Valuation",
                            color = NexoraTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        ReportLineItem(Localization.getString("customer_due_report", language), totalCustomerDue, NexoraCoralError, currency)
                        ReportLineItem(Localization.getString("supplier_payable_report", language), totalSupplierPayable, NexoraGoldAmber, currency)
                        ReportLineItem(Localization.getString("inventory_report", language), totalStockValuation, NexoraTealAccent, currency)
                        ReportLineItem("Inventory Items in Stock", products.sumOf { it.stockQuantity }, NexoraCyanPrimary, currency, isCurrency = false)
                    }
                }
            }

            // 4. Export Reports Actions
            item {
                SectionHeader(title = "Export Reports (CSV)")
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ExportActionTile(
                        title = Localization.getString("daily_sales_report", language),
                        icon = Icons.Default.PointOfSale,
                        accent = NexoraCyanPrimary,
                        onClick = {
                            val file = CsvExporter.exportSalesCsv(context, activeSales)
                            if (file != null) CsvExporter.shareCsv(context, file, "Sales Report CSV")
                            else Toast.makeText(context, "Export error", Toast.LENGTH_SHORT).show()
                        }
                    )
                    ExportActionTile(
                        title = "Purchases Report CSV",
                        icon = Icons.Default.Inventory,
                        accent = NexoraTealAccent,
                        onClick = {
                            val file = CsvExporter.exportPurchasesCsv(context, filteredPurchases)
                            if (file != null) CsvExporter.shareCsv(context, file, "Purchases Report CSV")
                            else Toast.makeText(context, "Export error", Toast.LENGTH_SHORT).show()
                        }
                    )
                    ExportActionTile(
                        title = Localization.getString("inventory_report", language),
                        icon = Icons.Default.Warehouse,
                        accent = NexoraGoldAmber,
                        onClick = {
                            val file = CsvExporter.exportInventoryCsv(context, products)
                            if (file != null) CsvExporter.shareCsv(context, file, "Inventory Report CSV")
                            else Toast.makeText(context, "Export error", Toast.LENGTH_SHORT).show()
                        }
                    )
                    ExportActionTile(
                        title = Localization.getString("customer_due_report", language),
                        icon = Icons.Default.People,
                        accent = NexoraCoralError,
                        onClick = {
                            val file = CsvExporter.exportCustomersCsv(context, customers)
                            if (file != null) CsvExporter.shareCsv(context, file, "Customers Due CSV")
                            else Toast.makeText(context, "Export error", Toast.LENGTH_SHORT).show()
                        }
                    )
                    ExportActionTile(
                        title = "Expense Report CSV",
                        icon = Icons.Default.ReceiptLong,
                        accent = NexoraEmeraldSuccess,
                        onClick = {
                            val file = CsvExporter.exportExpensesCsv(context, filteredExpenses)
                            if (file != null) CsvExporter.shareCsv(context, file, "Expense Report CSV")
                            else Toast.makeText(context, "Export error", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun ReportLineItem(
    label: String,
    value: Double,
    color: Color,
    currency: AppCurrency,
    isBold: Boolean = false,
    fontSize: androidx.compose.ui.unit.TextUnit = 14.sp,
    isCurrency: Boolean = true
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = if (isBold) NexoraTextPrimary else NexoraTextSecondary,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
            fontSize = fontSize
        )
        Text(
            text = if (isCurrency) Formatters.formatCurrency(value, currency) else "%.1f".format(value),
            color = color,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.SemiBold,
            fontSize = fontSize
        )
    }
}

@Composable
fun ExportActionTile(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = NexoraDarkSurface,
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
        modifier = Modifier.fillMaxWidth().testTag("export_csv_${title.lowercase().replace(" ", "_")}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(accent.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = null, tint = accent, modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text(text = title, color = NexoraTextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            }
            Icon(Icons.Default.Download, contentDescription = null, tint = NexoraCyanPrimary, modifier = Modifier.size(20.dp))
        }
    }
}
