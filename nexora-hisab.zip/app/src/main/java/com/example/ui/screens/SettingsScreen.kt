package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.ConfirmationDialog
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.BusinessProfile
import com.example.ui.viewmodel.NexoraViewModel
import com.example.util.AppCurrency
import com.example.util.AppLanguage
import com.example.util.BackupManager
import com.example.util.Localization

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: NexoraViewModel,
    currency: AppCurrency,
    language: AppLanguage,
    businessProfile: BusinessProfile,
    isPinEnabled: Boolean,
    allowNegativeStock: Boolean
) {
    var showBusinessProfileDialog by remember { mutableStateOf(false) }
    var showSetPinDialog by remember { mutableStateOf(false) }
    var showRestoreBackupDialog by remember { mutableStateOf(false) }
    var backupJsonInput by remember { mutableStateOf("") }

    val context = LocalContext.current

    Scaffold(
        containerColor = NexoraDarkBackground,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NexoraDarkSurface),
                title = {
                    Text(
                        text = Localization.getString("settings", language),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraTextPrimary
                        )
                    )
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Language & Currency Card
            item {
                Spacer(modifier = Modifier.height(4.dp))
                SectionHeader(title = "Language & Currency")
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NexoraDarkSurface),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = "Interface Language", color = NexoraTextSecondary, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = language == AppLanguage.BENGALI,
                                onClick = { viewModel.setLanguage(AppLanguage.BENGALI) },
                                label = { Text(AppLanguage.BENGALI.displayName) },
                                modifier = Modifier.weight(1f).testTag("select_bengali_button")
                            )
                            FilterChip(
                                selected = language == AppLanguage.ENGLISH,
                                onClick = { viewModel.setLanguage(AppLanguage.ENGLISH) },
                                label = { Text(AppLanguage.ENGLISH.displayName) },
                                modifier = Modifier.weight(1f).testTag("select_english_button")
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = NexoraDarkBorder)
                        Spacer(modifier = Modifier.height(14.dp))

                        Text(text = "Base Currency", color = NexoraTextSecondary, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = currency == AppCurrency.BDT,
                                onClick = { viewModel.setCurrency(AppCurrency.BDT) },
                                label = { Text(AppCurrency.BDT.displayName) },
                                modifier = Modifier.weight(1f).testTag("select_bdt_button")
                            )
                            FilterChip(
                                selected = currency == AppCurrency.USD,
                                onClick = { viewModel.setCurrency(AppCurrency.USD) },
                                label = { Text(AppCurrency.USD.displayName) },
                                modifier = Modifier.weight(1f).testTag("select_usd_button")
                            )
                        }
                    }
                }
            }

            // 2. Business Profile Card
            item {
                SectionHeader(
                    title = "Business Details & Invoice",
                    actionText = "Edit",
                    onActionClick = { showBusinessProfileDialog = true }
                )
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NexoraDarkSurface),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showBusinessProfileDialog = true }
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = businessProfile.name, color = NexoraTextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "Phone: ${businessProfile.phone}", color = NexoraTextSecondary, fontSize = 13.sp)
                        Text(text = "Address: ${businessProfile.address}", color = NexoraTextMuted, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = "Invoice Note: \"${businessProfile.invoiceNote}\"", color = NexoraCyanPrimary, fontSize = 11.sp)
                    }
                }
            }

            // 3. Security & Inventory Settings
            item {
                SectionHeader(title = "Security & Stock Rules")
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NexoraDarkSurface),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(Localization.getString("app_lock", language), color = NexoraTextPrimary, fontWeight = FontWeight.SemiBold)
                                Text("Require 4-digit PIN on app launch", color = NexoraTextSecondary, fontSize = 11.sp)
                            }
                            Switch(
                                checked = isPinEnabled,
                                onCheckedChange = { checked ->
                                    if (checked) {
                                        showSetPinDialog = true
                                    } else {
                                        viewModel.setPinEnabled(false)
                                    }
                                },
                                modifier = Modifier.testTag("pin_lock_switch")
                            )
                        }

                        if (isPinEnabled) {
                            TextButton(onClick = { showSetPinDialog = true }) {
                                Text("Change 4-Digit PIN", color = NexoraCyanPrimary, fontSize = 12.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = NexoraDarkBorder)
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(Localization.getString("allow_negative_stock", language), color = NexoraTextPrimary, fontWeight = FontWeight.SemiBold)
                                Text("Allow sales even if stock drops below zero", color = NexoraTextSecondary, fontSize = 11.sp)
                            }
                            Switch(
                                checked = allowNegativeStock,
                                onCheckedChange = { viewModel.setAllowNegativeStock(it) },
                                modifier = Modifier.testTag("negative_stock_switch")
                            )
                        }
                    }
                }
            }

            // 4. Backup & Restore
            item {
                SectionHeader(title = Localization.getString("backup_restore", language))
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NexoraDarkSurface),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = {
                                viewModel.createBackup { file ->
                                    if (file != null) {
                                        BackupManager.shareBackup(context, file)
                                    } else {
                                        Toast.makeText(context, "Backup creation failed", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NexoraDarkSurfaceVariant),
                            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraCyanPrimary)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().testTag("export_backup_button")
                        ) {
                            Icon(Icons.Default.CloudUpload, contentDescription = null, tint = NexoraCyanPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(Localization.getString("create_backup", language), color = NexoraCyanPrimary, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { showRestoreBackupDialog = true },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = NexoraGoldAmber),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().testTag("restore_backup_button")
                        ) {
                            Icon(Icons.Default.CloudDownload, contentDescription = null, tint = NexoraGoldAmber)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(Localization.getString("restore_backup", language), color = NexoraGoldAmber, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // 5. About App Info
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NexoraDarkSurface),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("NEXORA HISAB", color = NexoraCyanPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp, letterSpacing = 1.sp)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(Localization.getString("version", language), color = NexoraTextSecondary, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("100% Offline Architecture • Room Database • High Precision Accounting", color = NexoraTextMuted, fontSize = 10.sp)
                    }
                }
            }
        }
    }

    // Business Profile Dialog
    if (showBusinessProfileDialog) {
        var bName by remember { mutableStateOf(businessProfile.name) }
        var bPhone by remember { mutableStateOf(businessProfile.phone) }
        var bAddress by remember { mutableStateOf(businessProfile.address) }
        var bNote by remember { mutableStateOf(businessProfile.invoiceNote) }

        AlertDialog(
            onDismissRequest = { showBusinessProfileDialog = false },
            containerColor = NexoraDarkSurfaceVariant,
            title = { Text("Edit Business Profile", color = NexoraTextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = bName,
                        onValueChange = { bName = it },
                        label = { Text(Localization.getString("business_name", language)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = bPhone,
                        onValueChange = { bPhone = it },
                        label = { Text(Localization.getString("business_phone", language)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = bAddress,
                        onValueChange = { bAddress = it },
                        label = { Text(Localization.getString("business_address", language)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = bNote,
                        onValueChange = { bNote = it },
                        label = { Text("Invoice Footer Note") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.setBusinessProfile(bName, bPhone, bAddress, bNote)
                        showBusinessProfileDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NexoraCyanPrimary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(Localization.getString("save", language), color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showBusinessProfileDialog = false }) { Text(Localization.getString("cancel", language), color = NexoraTextSecondary) }
            }
        )
    }

    // Set PIN Dialog
    if (showSetPinDialog) {
        var pinInput by remember { mutableStateOf("") }
        var pinConfirmInput by remember { mutableStateOf("") }
        var pinError by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showSetPinDialog = false },
            containerColor = NexoraDarkSurfaceVariant,
            title = { Text(Localization.getString("set_pin", language), color = NexoraTextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Enter a 4-digit security PIN to protect your business records.", color = NexoraTextSecondary, fontSize = 12.sp)

                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) pinInput = it },
                        label = { Text("New 4-digit PIN") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = pinConfirmInput,
                        onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) pinConfirmInput = it },
                        label = { Text("Confirm PIN") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (pinError.isNotBlank()) {
                        Text(text = pinError, color = NexoraCoralError, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (pinInput.length != 4) {
                            pinError = "PIN must be exactly 4 digits"
                            return@Button
                        }
                        if (pinInput != pinConfirmInput) {
                            pinError = "PINs do not match"
                            return@Button
                        }
                        viewModel.setPin(pinInput)
                        Toast.makeText(context, "PIN set successfully!", Toast.LENGTH_SHORT).show()
                        showSetPinDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NexoraCyanPrimary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(Localization.getString("save", language), color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSetPinDialog = false }) { Text(Localization.getString("cancel", language), color = NexoraTextSecondary) }
            }
        )
    }

    // Restore Backup Dialog
    if (showRestoreBackupDialog) {
        AlertDialog(
            onDismissRequest = { showRestoreBackupDialog = false },
            containerColor = NexoraDarkSurfaceVariant,
            title = { Text("Restore Database from JSON", color = NexoraTextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Paste your Nexora Hisab JSON backup content below. WARNING: Valid records will be imported into your database.",
                        color = NexoraTextSecondary,
                        fontSize = 12.sp
                    )
                    OutlinedTextField(
                        value = backupJsonInput,
                        onValueChange = { backupJsonInput = it },
                        placeholder = { Text("Paste JSON backup here...") },
                        modifier = Modifier.fillMaxWidth().height(160.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (backupJsonInput.isBlank()) return@Button
                        viewModel.restoreBackup(backupJsonInput) { success ->
                            if (success) {
                                Toast.makeText(context, "Database restored successfully!", Toast.LENGTH_LONG).show()
                                showRestoreBackupDialog = false
                            } else {
                                Toast.makeText(context, "Invalid backup file or format error", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NexoraGoldAmber),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Restore", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRestoreBackupDialog = false }) { Text(Localization.getString("cancel", language), color = NexoraTextSecondary) }
            }
        )
    }
}
