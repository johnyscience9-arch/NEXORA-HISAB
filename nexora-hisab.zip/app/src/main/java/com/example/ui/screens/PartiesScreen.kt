package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Customer
import com.example.data.model.Payment
import com.example.data.model.Sale
import com.example.data.model.Supplier
import com.example.ui.components.ConfirmationDialog
import com.example.ui.components.EmptyStateView
import com.example.ui.components.NexoraSearchField
import com.example.ui.theme.*
import com.example.ui.viewmodel.NexoraViewModel
import com.example.util.AppCurrency
import com.example.util.AppLanguage
import com.example.util.Formatters
import com.example.util.Localization
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PartiesScreen(
    viewModel: NexoraViewModel,
    currency: AppCurrency,
    language: AppLanguage
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Customers, 1 = Suppliers

    val customers by viewModel.customers.collectAsState()
    val suppliers by viewModel.suppliers.collectAsState()
    val accounts by viewModel.accounts.collectAsState()

    var searchQuery by remember { mutableStateOf("") }

    // Dialog states
    var showAddCustomerDialog by remember { mutableStateOf(false) }
    var customerToEdit by remember { mutableStateOf<Customer?>(null) }
    var customerToDelete by remember { mutableStateOf<Customer?>(null) }

    var showAddSupplierDialog by remember { mutableStateOf(false) }
    var supplierToEdit by remember { mutableStateOf<Supplier?>(null) }
    var supplierToDelete by remember { mutableStateOf<Supplier?>(null) }

    var customerForPayment by remember { mutableStateOf<Customer?>(null) }
    var supplierForPayment by remember { mutableStateOf<Supplier?>(null) }

    var customerForStatement by remember { mutableStateOf<Customer?>(null) }
    var supplierForStatement by remember { mutableStateOf<Supplier?>(null) }

    val filteredCustomers = remember(customers, searchQuery) {
        if (searchQuery.isBlank()) customers
        else customers.filter { it.name.contains(searchQuery, ignoreCase = true) || it.phone.contains(searchQuery) }
    }

    val filteredSuppliers = remember(suppliers, searchQuery) {
        if (searchQuery.isBlank()) suppliers
        else suppliers.filter { it.name.contains(searchQuery, ignoreCase = true) || it.phone.contains(searchQuery) }
    }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    Scaffold(
        containerColor = NexoraDarkBackground,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NexoraDarkSurface),
                title = {
                    Text(
                        text = Localization.getString("parties", language),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraTextPrimary
                        )
                    )
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    if (selectedTab == 0) {
                        customerToEdit = null
                        showAddCustomerDialog = true
                    } else {
                        supplierToEdit = null
                        showAddSupplierDialog = true
                    }
                },
                containerColor = if (selectedTab == 0) NexoraCyanPrimary else NexoraTealAccent,
                contentColor = Color.Black,
                icon = { Icon(Icons.Default.PersonAdd, contentDescription = null) },
                text = {
                    Text(
                        text = if (selectedTab == 0) Localization.getString("add_customer", language) else Localization.getString("add_supplier", language),
                        fontWeight = FontWeight.Bold
                    )
                },
                modifier = Modifier
                    .navigationBarsPadding()
                    .testTag("add_party_fab")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            // Dual Tabs: Customers & Suppliers
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = NexoraDarkSurface,
                contentColor = if (selectedTab == 0) NexoraCyanPrimary else NexoraTealAccent
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Text(
                            text = "${Localization.getString("customers", language)} (${customers.size})",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Text(
                            text = "${Localization.getString("suppliers", language)} (${suppliers.size})",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            NexoraSearchField(
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                placeholder = if (selectedTab == 0) "Search customers by name or phone..." else "Search suppliers by name or phone..."
            )

            Spacer(modifier = Modifier.height(10.dp))

            if (selectedTab == 0) {
                // Customers List
                if (filteredCustomers.isEmpty()) {
                    EmptyStateView(
                        icon = Icons.Default.People,
                        title = Localization.getString("no_data", language),
                        message = "No customers added yet. Add customers to track dues and payment ledgers.",
                        actionLabel = Localization.getString("add_customer", language),
                        onActionClick = {
                            customerToEdit = null
                            showAddCustomerDialog = true
                        }
                    )
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(bottom = 90.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(filteredCustomers, key = { it.id }) { customer ->
                            CustomerItemCard(
                                customer = customer,
                                currency = currency,
                                language = language,
                                onReceivePayment = { customerForPayment = customer },
                                onStatement = { customerForStatement = customer },
                                onEdit = {
                                    customerToEdit = customer
                                    showAddCustomerDialog = true
                                },
                                onDelete = { customerToDelete = customer }
                            )
                        }
                    }
                }
            } else {
                // Suppliers List
                if (filteredSuppliers.isEmpty()) {
                    EmptyStateView(
                        icon = Icons.Default.LocalShipping,
                        title = Localization.getString("no_data", language),
                        message = "No suppliers added yet. Add suppliers to track inventory purchases and payables.",
                        actionLabel = Localization.getString("add_supplier", language),
                        onActionClick = {
                            supplierToEdit = null
                            showAddSupplierDialog = true
                        }
                    )
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(bottom = 90.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(filteredSuppliers, key = { it.id }) { supplier ->
                            SupplierItemCard(
                                supplier = supplier,
                                currency = currency,
                                language = language,
                                onPay = { supplierForPayment = supplier },
                                onStatement = { supplierForStatement = supplier },
                                onEdit = {
                                    supplierToEdit = supplier
                                    showAddSupplierDialog = true
                                },
                                onDelete = { supplierToDelete = supplier }
                            )
                        }
                    }
                }
            }
        }
    }

    // Add / Edit Customer Dialog
    if (showAddCustomerDialog) {
        AddEditCustomerDialog(
            customer = customerToEdit,
            currency = currency,
            language = language,
            onDismiss = { showAddCustomerDialog = false },
            onSave = { c ->
                viewModel.saveCustomer(c) {
                    Toast.makeText(context, "Customer saved!", Toast.LENGTH_SHORT).show()
                }
                showAddCustomerDialog = false
            }
        )
    }

    // Add / Edit Supplier Dialog
    if (showAddSupplierDialog) {
        AddEditSupplierDialog(
            supplier = supplierToEdit,
            currency = currency,
            language = language,
            onDismiss = { showAddSupplierDialog = false },
            onSave = { s ->
                viewModel.saveSupplier(s) {
                    Toast.makeText(context, "Supplier saved!", Toast.LENGTH_SHORT).show()
                }
                showAddSupplierDialog = false
            }
        )
    }

    // Delete Customer Confirmation
    customerToDelete?.let { c ->
        ConfirmationDialog(
            title = Localization.getString("confirm_delete", language),
            message = "Are you sure you want to delete customer '${c.name}'?",
            confirmText = Localization.getString("delete", language),
            cancelText = Localization.getString("cancel", language),
            isDestructive = true,
            onConfirm = {
                viewModel.deleteCustomer(c)
                customerToDelete = null
            },
            onDismiss = { customerToDelete = null }
        )
    }

    // Delete Supplier Confirmation
    supplierToDelete?.let { s ->
        ConfirmationDialog(
            title = Localization.getString("confirm_delete", language),
            message = "Are you sure you want to delete supplier '${s.name}'?",
            confirmText = Localization.getString("delete", language),
            cancelText = Localization.getString("cancel", language),
            isDestructive = true,
            onConfirm = {
                viewModel.deleteSupplier(s)
                supplierToDelete = null
            },
            onDismiss = { supplierToDelete = null }
        )
    }

    // Receive Payment Dialog (Customer)
    customerForPayment?.let { customer ->
        PaymentActionDialog(
            title = "Receive Money from ${customer.name}",
            dueAmount = customer.currentDue,
            isReceiving = true,
            currency = currency,
            language = language,
            onDismiss = { customerForPayment = null },
            onConfirm = { amount, method, refNo, notes ->
                val cashAcc = accounts.firstOrNull { it.accountType == "CASH" }
                val bankAcc = accounts.firstOrNull { it.accountType == "BANK" }
                val accId = if (method == "BANK") bankAcc?.id ?: 2L else cashAcc?.id ?: 1L

                viewModel.recordCustomerPayment(
                    customerId = customer.id,
                    customerName = customer.name,
                    amount = amount,
                    paymentMethod = method,
                    accountId = accId,
                    referenceNo = refNo,
                    notes = notes,
                    onSuccess = {
                        Toast.makeText(context, "Payment received and customer balance updated!", Toast.LENGTH_SHORT).show()
                        customerForPayment = null
                    }
                )
            }
        )
    }

    // Pay Supplier Dialog
    supplierForPayment?.let { supplier ->
        PaymentActionDialog(
            title = "Pay Supplier: ${supplier.name}",
            dueAmount = supplier.currentPayable,
            isReceiving = false,
            currency = currency,
            language = language,
            onDismiss = { supplierForPayment = null },
            onConfirm = { amount, method, refNo, notes ->
                val cashAcc = accounts.firstOrNull { it.accountType == "CASH" }
                val bankAcc = accounts.firstOrNull { it.accountType == "BANK" }
                val accId = if (method == "BANK") bankAcc?.id ?: 2L else cashAcc?.id ?: 1L

                viewModel.recordSupplierPayment(
                    supplierId = supplier.id,
                    supplierName = supplier.name,
                    amount = amount,
                    paymentMethod = method,
                    accountId = accId,
                    referenceNo = refNo,
                    notes = notes,
                    onSuccess = {
                        Toast.makeText(context, "Supplier payment recorded!", Toast.LENGTH_SHORT).show()
                        supplierForPayment = null
                    }
                )
            }
        )
    }

    // Customer Statement Dialog
    customerForStatement?.let { customer ->
        var salesList by remember { mutableStateOf<List<Sale>>(emptyList()) }
        var paymentsList by remember { mutableStateOf<List<Payment>>(emptyList()) }

        LaunchedEffect(customer.id) {
            salesList = viewModel.repository.getSalesByCustomer(customer.id).first()
            paymentsList = viewModel.repository.getPaymentsByParty("CUSTOMER", customer.id).first()
        }

        AlertDialog(
            onDismissRequest = { customerForStatement = null },
            containerColor = NexoraDarkSurfaceVariant,
            title = {
                Column {
                    Text(text = "${customer.name} - Statement", color = NexoraTextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(text = "Current Due: ${Formatters.formatCurrency(customer.currentDue, currency)}", color = NexoraCoralError, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth().heightIn(max = 350.dp)) {
                    Text(text = "Transaction History:", color = NexoraCyanPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))

                    if (salesList.isEmpty() && paymentsList.isEmpty()) {
                        Text(text = "No recorded transactions for this customer yet.", color = NexoraTextMuted)
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(salesList) { s ->
                                Surface(shape = RoundedCornerShape(8.dp), color = NexoraDarkSurface, modifier = Modifier.fillMaxWidth()) {
                                    Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Column {
                                            Text(text = "Invoice #${s.invoiceNumber}", color = NexoraTextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            Text(text = Formatters.formatDate(s.date), color = NexoraTextMuted, fontSize = 10.sp)
                                        }
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(text = Formatters.formatCurrency(s.grandTotal, currency), color = NexoraTextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            Text(text = "Due: ${Formatters.formatCurrency(s.dueAmount, currency)}", color = NexoraCoralError, fontSize = 10.sp)
                                        }
                                    }
                                }
                            }
                            items(paymentsList) { p ->
                                Surface(shape = RoundedCornerShape(8.dp), color = NexoraDarkSurface, modifier = Modifier.fillMaxWidth()) {
                                    Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Column {
                                            Text(text = "Payment Received (${p.paymentMethod})", color = NexoraEmeraldSuccess, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            Text(text = Formatters.formatDate(p.date), color = NexoraTextMuted, fontSize = 10.sp)
                                        }
                                        Text(text = "-${Formatters.formatCurrency(p.amount, currency)}", color = NexoraEmeraldSuccess, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { customerForStatement = null }) { Text("Close", color = NexoraCyanPrimary) }
            }
        )
    }

    // Supplier Statement Dialog
    supplierForStatement?.let { supplier ->
        var purchasesList by remember { mutableStateOf<List<com.example.data.model.Purchase>>(emptyList()) }
        var paymentsList by remember { mutableStateOf<List<Payment>>(emptyList()) }

        LaunchedEffect(supplier.id) {
            purchasesList = viewModel.repository.getPurchasesBySupplier(supplier.id).first()
            paymentsList = viewModel.repository.getPaymentsByParty("SUPPLIER", supplier.id).first()
        }

        AlertDialog(
            onDismissRequest = { supplierForStatement = null },
            containerColor = NexoraDarkSurfaceVariant,
            title = {
                Column {
                    Text(text = "${supplier.name} - Statement", color = NexoraTextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(text = "Payable Balance: ${Formatters.formatCurrency(supplier.currentPayable, currency)}", color = NexoraGoldAmber, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth().heightIn(max = 350.dp)) {
                    Text(text = "Purchase & Payment History:", color = NexoraTealAccent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))

                    if (purchasesList.isEmpty() && paymentsList.isEmpty()) {
                        Text(text = "No recorded transactions for this supplier yet.", color = NexoraTextMuted)
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(purchasesList) { p ->
                                Surface(shape = RoundedCornerShape(8.dp), color = NexoraDarkSurface, modifier = Modifier.fillMaxWidth()) {
                                    Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Column {
                                            Text(text = "Purchase #${p.invoiceNumber}", color = NexoraTextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            Text(text = Formatters.formatDate(p.date), color = NexoraTextMuted, fontSize = 10.sp)
                                        }
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(text = Formatters.formatCurrency(p.grandTotal, currency), color = NexoraTextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            Text(text = "Payable: ${Formatters.formatCurrency(p.remainingPayable, currency)}", color = NexoraGoldAmber, fontSize = 10.sp)
                                        }
                                    }
                                }
                            }
                            items(paymentsList) { pm ->
                                Surface(shape = RoundedCornerShape(8.dp), color = NexoraDarkSurface, modifier = Modifier.fillMaxWidth()) {
                                    Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Column {
                                            Text(text = "Paid to Supplier (${pm.paymentMethod})", color = NexoraTealAccent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            Text(text = Formatters.formatDate(pm.date), color = NexoraTextMuted, fontSize = 10.sp)
                                        }
                                        Text(text = "-${Formatters.formatCurrency(pm.amount, currency)}", color = NexoraTealAccent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { supplierForStatement = null }) { Text("Close", color = NexoraTealAccent) }
            }
        )
    }
}

@Composable
fun CustomerItemCard(
    customer: Customer,
    currency: AppCurrency,
    language: AppLanguage,
    onReceivePayment: () -> Unit,
    onStatement: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = NexoraDarkSurface),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
        modifier = Modifier.fillMaxWidth().testTag("customer_card_${customer.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = customer.name,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraTextPrimary,
                            fontSize = 15.sp
                        )
                    )
                    if (customer.phone.isNotBlank()) {
                        Text(text = customer.phone, color = NexoraTextSecondary, fontSize = 12.sp)
                    }
                    if (customer.address.isNotBlank()) {
                        Text(text = customer.address, color = NexoraTextMuted, fontSize = 11.sp)
                    }
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = Formatters.formatCurrency(customer.currentDue, currency),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (customer.currentDue > 0) NexoraCoralError else NexoraEmeraldSuccess,
                            fontSize = 16.sp
                        )
                    )
                    Text(
                        text = if (customer.currentDue > 0) "Total Due" else "Clear Balance",
                        color = if (customer.currentDue > 0) NexoraCoralError else NexoraEmeraldSuccess,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = NexoraDarkBorder)
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onReceivePayment,
                        colors = ButtonDefaults.buttonColors(containerColor = NexoraEmeraldSuccess),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("customer_receive_payment_button")
                    ) {
                        Text("Receive Money", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = onStatement,
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(Localization.getString("statement", language), color = NexoraCyanPrimary, fontSize = 11.sp)
                    }
                }

                Row {
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit", tint = NexoraCyanPrimary, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = NexoraCoralError, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun SupplierItemCard(
    supplier: Supplier,
    currency: AppCurrency,
    language: AppLanguage,
    onPay: () -> Unit,
    onStatement: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = NexoraDarkSurface),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
        modifier = Modifier.fillMaxWidth().testTag("supplier_card_${supplier.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = supplier.name,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraTextPrimary,
                            fontSize = 15.sp
                        )
                    )
                    if (supplier.phone.isNotBlank()) {
                        Text(text = supplier.phone, color = NexoraTextSecondary, fontSize = 12.sp)
                    }
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = Formatters.formatCurrency(supplier.currentPayable, currency),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (supplier.currentPayable > 0) NexoraGoldAmber else NexoraEmeraldSuccess,
                            fontSize = 16.sp
                        )
                    )
                    Text(
                        text = if (supplier.currentPayable > 0) "Total Payable" else "Clear",
                        color = if (supplier.currentPayable > 0) NexoraGoldAmber else NexoraEmeraldSuccess,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = NexoraDarkBorder)
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onPay,
                        colors = ButtonDefaults.buttonColors(containerColor = NexoraTealAccent),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("supplier_pay_button")
                    ) {
                        Text("Pay Supplier", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = onStatement,
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(Localization.getString("statement", language), color = NexoraTealAccent, fontSize = 11.sp)
                    }
                }

                Row {
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit", tint = NexoraCyanPrimary, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = NexoraCoralError, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun AddEditCustomerDialog(
    customer: Customer?,
    currency: AppCurrency,
    language: AppLanguage,
    onDismiss: () -> Unit,
    onSave: (Customer) -> Unit
) {
    var name by remember { mutableStateOf(customer?.name ?: "") }
    var phone by remember { mutableStateOf(customer?.phone ?: "") }
    var address by remember { mutableStateOf(customer?.address ?: "") }
    var openingBalanceInput by remember { mutableStateOf(customer?.openingBalance?.toString() ?: "0") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NexoraDarkSurfaceVariant,
        title = {
            Text(
                text = if (customer == null) Localization.getString("add_customer", language) else Localization.getString("edit_customer", language),
                color = NexoraTextPrimary,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(Localization.getString("name", language)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text(Localization.getString("phone", language)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text(Localization.getString("address", language)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (customer == null) {
                    OutlinedTextField(
                        value = openingBalanceInput,
                        onValueChange = { openingBalanceInput = it },
                        label = { Text("Opening Due Balance (${currency.symbol})") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) return@Button
                    val opening = openingBalanceInput.toDoubleOrNull() ?: 0.0
                    val updated = Customer(
                        id = customer?.id ?: 0L,
                        name = name.trim(),
                        phone = phone.trim(),
                        address = address.trim(),
                        openingBalance = customer?.openingBalance ?: opening,
                        currentDue = customer?.currentDue ?: opening
                    )
                    onSave(updated)
                },
                colors = ButtonDefaults.buttonColors(containerColor = NexoraCyanPrimary),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("save_customer_button")
            ) {
                Text(Localization.getString("save", language), color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(Localization.getString("cancel", language), color = NexoraTextSecondary) }
        }
    )
}

@Composable
fun AddEditSupplierDialog(
    supplier: Supplier?,
    currency: AppCurrency,
    language: AppLanguage,
    onDismiss: () -> Unit,
    onSave: (Supplier) -> Unit
) {
    var name by remember { mutableStateOf(supplier?.name ?: "") }
    var phone by remember { mutableStateOf(supplier?.phone ?: "") }
    var address by remember { mutableStateOf(supplier?.address ?: "") }
    var openingBalanceInput by remember { mutableStateOf(supplier?.openingBalance?.toString() ?: "0") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NexoraDarkSurfaceVariant,
        title = {
            Text(
                text = if (supplier == null) Localization.getString("add_supplier", language) else Localization.getString("edit_supplier", language),
                color = NexoraTextPrimary,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(Localization.getString("name", language)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text(Localization.getString("phone", language)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text(Localization.getString("address", language)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (supplier == null) {
                    OutlinedTextField(
                        value = openingBalanceInput,
                        onValueChange = { openingBalanceInput = it },
                        label = { Text("Opening Payable Balance (${currency.symbol})") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) return@Button
                    val opening = openingBalanceInput.toDoubleOrNull() ?: 0.0
                    val updated = Supplier(
                        id = supplier?.id ?: 0L,
                        name = name.trim(),
                        phone = phone.trim(),
                        address = address.trim(),
                        openingBalance = supplier?.openingBalance ?: opening,
                        currentPayable = supplier?.currentPayable ?: opening
                    )
                    onSave(updated)
                },
                colors = ButtonDefaults.buttonColors(containerColor = NexoraTealAccent),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("save_supplier_button")
            ) {
                Text(Localization.getString("save", language), color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(Localization.getString("cancel", language), color = NexoraTextSecondary) }
        }
    )
}

@Composable
fun PaymentActionDialog(
    title: String,
    dueAmount: Double,
    isReceiving: Boolean,
    currency: AppCurrency,
    language: AppLanguage,
    onDismiss: () -> Unit,
    onConfirm: (Double, String, String, String) -> Unit
) {
    var amountInput by remember { mutableStateOf(dueAmount.coerceAtLeast(0.0).toString()) }
    var paymentMethod by remember { mutableStateOf("CASH") }
    var refNo by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NexoraDarkSurfaceVariant,
        title = { Text(text = title, color = NexoraTextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Outstanding Balance: ${Formatters.formatCurrency(dueAmount, currency)}",
                    color = if (isReceiving) NexoraCoralError else NexoraGoldAmber,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )

                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it },
                    label = { Text(Localization.getString("amount", language)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(text = Localization.getString("payment_method", language), color = NexoraTextSecondary, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = paymentMethod == "CASH",
                        onClick = { paymentMethod = "CASH" },
                        label = { Text(Localization.getString("cash_account", language)) },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = paymentMethod == "BANK",
                        onClick = { paymentMethod = "BANK" },
                        label = { Text(Localization.getString("bank_account", language)) },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = refNo,
                    onValueChange = { refNo = it },
                    label = { Text(Localization.getString("reference_no", language)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text(Localization.getString("notes", language)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountInput.toDoubleOrNull() ?: 0.0
                    if (amt <= 0) return@Button
                    onConfirm(amt, paymentMethod, refNo, notes)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isReceiving) NexoraEmeraldSuccess else NexoraTealAccent
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("submit_payment_action_button")
            ) {
                Text(
                    text = if (isReceiving) "Receive" else "Pay",
                    color = Color.Black,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(Localization.getString("cancel", language), color = NexoraTextSecondary) }
        }
    )
}
