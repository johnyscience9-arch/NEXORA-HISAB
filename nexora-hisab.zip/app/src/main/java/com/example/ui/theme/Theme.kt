package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = NexoraCyanPrimary,
    onPrimary = Color(0xFF00363D),
    primaryContainer = Color(0xFF004F58),
    onPrimaryContainer = Color(0xFF9EEFFE),
    secondary = NexoraTealAccent,
    onSecondary = Color(0xFF00382E),
    secondaryContainer = Color(0xFF005144),
    onSecondaryContainer = Color(0xFF73F8DC),
    tertiary = NexoraGoldAmber,
    onTertiary = Color(0xFF432C00),
    tertiaryContainer = Color(0xFF604100),
    onTertiaryContainer = Color(0xFFFFDF9E),
    background = NexoraDarkBackground,
    onBackground = NexoraTextPrimary,
    surface = NexoraDarkSurface,
    onSurface = NexoraTextPrimary,
    surfaceVariant = NexoraDarkSurfaceVariant,
    onSurfaceVariant = NexoraTextSecondary,
    surfaceContainerHighest = NexoraSurfaceContainerHighest,
    outline = NexoraDarkBorder,
    outlineVariant = Color(0xFF334155),
    error = NexoraCoralError,
    onError = Color.White
)

@Composable
fun NexoraTheme(
    darkTheme: Boolean = true, // Premium Dark by default for commercial financial UI
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
