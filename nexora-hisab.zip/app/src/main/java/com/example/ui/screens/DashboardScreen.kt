package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AccountTransaction
import com.example.ui.components.EmptyStateView
import com.example.ui.components.MetricCard
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.DashboardMetrics
import com.example.util.AppCurrency
import com.example.util.AppLanguage
import com.example.util.Formatters
import com.example.util.Localization

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    metrics: DashboardMetrics,
    currency: AppCurrency,
    language: AppLanguage,
    businessName: String,
    recentTransactions: List<AccountTransaction>,
    onNavigateToCreateSale: () -> Unit,
    onNavigateToCreatePurchase: () -> Unit,
    onNavigateToParties: () -> Unit,
    onNavigateToExpenses: () -> Unit,
    onNavigateToReports: () -> Unit,
    onToggleCurrency: () -> Unit,
    onToggleLanguage: () -> Unit
) {
    var selectedSummaryTab by remember { mutableIntStateOf(0) } // 0 = Daily, 1 = Weekly, 2 = Monthly

    Scaffold(
        containerColor = NexoraDarkBackground,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = NexoraDarkSurface
                ),
                title = {
                    Column {
                        Text(
                            text = businessName.ifBlank { "NEXORA HISAB" },
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = NexoraTextPrimary
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = Localization.getString("dashboard", language),
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = NexoraCyanPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                },
                actions = {
                    // Currency Toggle Pill
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = NexoraDarkSurfaceVariant,
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .clickable { onToggleCurrency() }
                            .testTag("toggle_currency_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = currency.code,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NexoraGoldAmber
                                )
                            )
                        }
                    }

                    // Language Toggle Pill
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = NexoraDarkSurfaceVariant,
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .clickable { onToggleLanguage() }
                            .testTag("toggle_language_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = if (language == AppLanguage.BENGALI) "বাং" else "EN",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NexoraCyanPrimary
                                )
                            )
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Primary 2x2 Metric Grid (Sales, Purchases, Expenses, Profit)
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MetricCard(
                        title = Localization.getString("total_sales", language),
                        value = Formatters.formatCurrency(metrics.totalSales, currency),
                        icon = Icons.Default.ShoppingCart,
                        accentColor = NexoraCyanPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = Localization.getString("total_purchases", language),
                        value = Formatters.formatCurrency(metrics.totalPurchases, currency),
                        icon = Icons.Default.Inventory2,
                        accentColor = NexoraTealAccent,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MetricCard(
                        title = Localization.getString("total_expenses", language),
                        value = Formatters.formatCurrency(metrics.totalExpenses, currency),
                        icon = Icons.Default.ReceiptLong,
                        accentColor = NexoraGoldAmber,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = Localization.getString("total_profit", language),
                        value = Formatters.formatCurrency(metrics.totalProfit, currency),
                        icon = Icons.AutoMirrored.Filled.TrendingUp,
                        accentColor = if (metrics.totalProfit >= 0) NexoraEmeraldSuccess else NexoraCoralError,
                        subtext = "COGS calculated",
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToReports
                    )
                }
            }

            // 2. Secondary Financial Cards: Cash, Customer Due, Supplier Payable, Stock Value
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NexoraDarkSurface),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            FinancialStatItem(
                                label = Localization.getString("total_cash", language),
                                value = Formatters.formatCurrency(metrics.totalCash, currency),
                                color = NexoraEmeraldSuccess
                            )
                            FinancialStatItem(
                                label = Localization.getString("customer_due", language),
                                value = Formatters.formatCurrency(metrics.totalCustomerDue, currency),
                                color = NexoraCoralError
                            )
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = NexoraDarkBorder)
                        Spacer(modifier = Modifier.height(14.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            FinancialStatItem(
                                label = Localization.getString("supplier_due", language),
                                value = Formatters.formatCurrency(metrics.totalSupplierDue, currency),
                                color = NexoraGoldAmber
                            )
                            FinancialStatItem(
                                label = Localization.getString("stock_value", language),
                                value = Formatters.formatCurrency(metrics.totalStockValue, currency),
                                color = NexoraCyanPrimary
                            )
                        }
                    }
                }
            }

            // 3. Quick Action Buttons
            item {
                SectionHeader(title = Localization.getString("quick_actions", language))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    QuickActionButton(
                        label = Localization.getString("new_sale", language),
                        icon = Icons.Default.PointOfSale,
                        accent = NexoraCyanPrimary,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToCreateSale
                    )
                    QuickActionButton(
                        label = Localization.getString("new_purchase", language),
                        icon = Icons.Default.AddShoppingCart,
                        accent = NexoraTealAccent,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToCreatePurchase
                    )
                    QuickActionButton(
                        label = Localization.getString("new_expense", language),
                        icon = Icons.Default.Payments,
                        accent = NexoraGoldAmber,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToExpenses
                    )
                }
            }

            // 4. Periodic Summary (Daily / Weekly / Monthly)
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NexoraDarkSurface),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        TabRow(
                            selectedTabIndex = selectedSummaryTab,
                            containerColor = Color.Transparent,
                            contentColor = NexoraCyanPrimary,
                            divider = {}
                        ) {
                            Tab(
                                selected = selectedSummaryTab == 0,
                                onClick = { selectedSummaryTab = 0 },
                                text = { Text(Localization.getString("daily_summary", language), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                            )
                            Tab(
                                selected = selectedSummaryTab == 1,
                                onClick = { selectedSummaryTab = 1 },
                                text = { Text(Localization.getString("weekly_summary", language), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                            )
                            Tab(
                                selected = selectedSummaryTab == 2,
                                onClick = { selectedSummaryTab = 2 },
                                text = { Text(Localization.getString("monthly_summary", language), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        val (sSales, sPurchases, sExpenses, sProfit) = when (selectedSummaryTab) {
                            0 -> listOf(metrics.todaySales, metrics.todayPurchases, metrics.todayExpenses, metrics.todayProfit)
                            1 -> listOf(metrics.weekSales, metrics.weekPurchases, metrics.weekExpenses, metrics.weekProfit)
                            else -> listOf(metrics.monthSales, metrics.monthPurchases, metrics.monthExpenses, metrics.monthProfit)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            SummaryStatPill(
                                label = Localization.getString("sales", language),
                                value = Formatters.formatCurrency(sSales, currency),
                                color = NexoraCyanPrimary
                            )
                            SummaryStatPill(
                                label = Localization.getString("purchases", language),
                                value = Formatters.formatCurrency(sPurchases, currency),
                                color = NexoraTealAccent
                            )
                            SummaryStatPill(
                                label = Localization.getString("expenses", language),
                                value = Formatters.formatCurrency(sExpenses, currency),
                                color = NexoraGoldAmber
                            )
                            SummaryStatPill(
                                label = "Profit",
                                value = Formatters.formatCurrency(sProfit, currency),
                                color = if (sProfit >= 0) NexoraEmeraldSuccess else NexoraCoralError
                            )
                        }
                    }
                }
            }

            // 5. Recent Transactions
            item {
                SectionHeader(
                    title = Localization.getString("recent_transactions", language),
                    actionText = Localization.getString("all", language),
                    onActionClick = onNavigateToReports
                )
            }

            if (recentTransactions.isEmpty()) {
                item {
                    EmptyStateView(
                        icon = Icons.Default.Receipt,
                        title = Localization.getString("no_data", language),
                        message = "Your financial transactions will appear here as you record sales, purchases, or payments.",
                        actionLabel = Localization.getString("new_sale", language),
                        onActionClick = onNavigateToCreateSale
                    )
                }
            } else {
                items(recentTransactions.take(15)) { tx ->
                    TransactionRowItem(tx = tx, currency = currency)
                }
            }
        }
    }
}

@Composable
private fun FinancialStatItem(label: String, value: String, color: Color) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall.copy(
                color = NexoraTextSecondary,
                fontSize = 12.sp
            )
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = color
            )
        )
    }
}

@Composable
private fun SummaryStatPill(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, color = NexoraTextMuted, fontSize = 11.sp)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun QuickActionButton(
    label: String,
    icon: ImageVector,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = NexoraDarkSurface,
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
        modifier = modifier.testTag("quick_action_${label.lowercase().replace(" ", "_")}")
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(accent.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = NexoraTextPrimary,
                    fontSize = 11.sp
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun TransactionRowItem(tx: AccountTransaction, currency: AppCurrency) {
    val isPositive = tx.amount >= 0
    val amountColor = if (isPositive) NexoraEmeraldSuccess else NexoraCoralError

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NexoraDarkSurface),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("transaction_item_${tx.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(
                            when (tx.type) {
                                "SALE_PAYMENT", "CUSTOMER_PAYMENT" -> NexoraEmeraldSuccess.copy(alpha = 0.15f)
                                "PURCHASE_PAYMENT", "SUPPLIER_PAYMENT" -> NexoraTealAccent.copy(alpha = 0.15f)
                                "EXPENSE" -> NexoraCoralError.copy(alpha = 0.15f)
                                else -> NexoraCyanPrimary.copy(alpha = 0.15f)
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when (tx.type) {
                            "SALE_PAYMENT", "CUSTOMER_PAYMENT" -> Icons.Default.ArrowDownward
                            "PURCHASE_PAYMENT", "SUPPLIER_PAYMENT" -> Icons.Default.ArrowUpward
                            "EXPENSE" -> Icons.Default.Receipt
                            else -> Icons.Default.SwapHoriz
                        },
                        contentDescription = null,
                        tint = when (tx.type) {
                            "SALE_PAYMENT", "CUSTOMER_PAYMENT" -> NexoraEmeraldSuccess
                            "PURCHASE_PAYMENT", "SUPPLIER_PAYMENT" -> NexoraTealAccent
                            "EXPENSE" -> NexoraCoralError
                            else -> NexoraCyanPrimary
                        },
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = tx.description.ifBlank { tx.type.replace("_", " ") },
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = NexoraTextPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = Formatters.formatDateTime(tx.date),
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NexoraTextMuted,
                            fontSize = 11.sp
                        )
                    )
                }
            }
            Text(
                text = "${if (isPositive) "+" else ""}${Formatters.formatCurrency(tx.amount, currency)}",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = amountColor,
                    fontSize = 14.sp
                )
            )
        }
    }
}
