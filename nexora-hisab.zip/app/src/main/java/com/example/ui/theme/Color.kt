package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NexoraDarkBackground = Color(0xFF090D16)
val NexoraDarkSurface = Color(0xFF111726)
val NexoraDarkSurfaceVariant = Color(0xFF182238)
val NexoraDarkBorder = Color(0xFF23304B)

val NexoraCyanPrimary = Color(0xFF00E5FF)
val NexoraTealAccent = Color(0xFF00D2B4)
val NexoraGoldAmber = Color(0xFFFFB300)
val NexoraEmeraldSuccess = Color(0xFF00E676)
val NexoraCoralError = Color(0xFFFF5252)
val NexoraPurpleAccent = Color(0xFF8B5CF6)

val NexoraTextPrimary = Color(0xFFF1F5F9)
val NexoraTextSecondary = Color(0xFF94A3B8)
val NexoraTextMuted = Color(0xFF64748B)

val NexoraSurfaceContainerHighest = Color(0xFF1E293B)
