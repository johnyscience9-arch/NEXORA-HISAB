package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.*
import com.example.data.preferences.AppPreferences
import com.example.data.repository.NexoraRepository
import com.example.util.AppCurrency
import com.example.util.AppLanguage
import com.example.util.BackupManager
import com.example.util.Formatters
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File

data class DashboardMetrics(
    val totalSales: Double = 0.0,
    val totalPurchases: Double = 0.0,
    val totalExpenses: Double = 0.0,
    val totalProfit: Double = 0.0,
    val totalCash: Double = 0.0,
    val totalBank: Double = 0.0,
    val totalCustomerDue: Double = 0.0,
    val totalSupplierDue: Double = 0.0,
    val totalStockValue: Double = 0.0,
    // Daily summary
    val todaySales: Double = 0.0,
    val todayPurchases: Double = 0.0,
    val todayExpenses: Double = 0.0,
    val todayProfit: Double = 0.0,
    // Weekly summary
    val weekSales: Double = 0.0,
    val weekPurchases: Double = 0.0,
    val weekExpenses: Double = 0.0,
    val weekProfit: Double = 0.0,
    // Monthly summary
    val monthSales: Double = 0.0,
    val monthPurchases: Double = 0.0,
    val monthExpenses: Double = 0.0,
    val monthProfit: Double = 0.0
)

data class BusinessProfile(
    val name: String = "Nexora Enterprise",
    val phone: String = "+880 1700-000000",
    val address: String = "Dhaka, Bangladesh",
    val invoiceNote: String = "Thank you for your business!"
)

class NexoraViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    val repository = NexoraRepository(db)
    val preferences = AppPreferences(application)

    val language: StateFlow<AppLanguage> = preferences.languageFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppLanguage.BENGALI)

    val currency: StateFlow<AppCurrency> = preferences.currencyFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppCurrency.BDT)

    val isPinEnabled: StateFlow<Boolean> = preferences.pinEnabledFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    val pinHash: StateFlow<String> = preferences.pinHashFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, "")

    val isAppUnlocked = MutableStateFlow(true)

    val allowNegativeStock: StateFlow<Boolean> = preferences.allowNegativeStockFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    val businessProfile: StateFlow<BusinessProfile> = combine(
        preferences.businessNameFlow,
        preferences.businessPhoneFlow,
        preferences.businessAddressFlow,
        preferences.invoiceNoteFlow
    ) { name, phone, address, note ->
        BusinessProfile(name, phone, address, note)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, BusinessProfile())

    // Database entities streams
    val customers: StateFlow<List<Customer>> = repository.allCustomers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val suppliers: StateFlow<List<Supplier>> = repository.allSuppliers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val products: StateFlow<List<Product>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lowStockProducts: StateFlow<List<Product>> = repository.lowStockProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val categories: StateFlow<List<Category>> = repository.allCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val accounts: StateFlow<List<Account>> = repository.allAccounts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sales: StateFlow<List<Sale>> = repository.allSales
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val purchases: StateFlow<List<Purchase>> = repository.allPurchases
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val expenses: StateFlow<List<Expense>> = repository.allExpenses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val payments: StateFlow<List<Payment>> = repository.allPayments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentTransactions: StateFlow<List<AccountTransaction>> = repository.recentTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private data class SecondaryMetrics(
        val accounts: List<Account>,
        val customers: List<Customer>,
        val suppliers: List<Supplier>,
        val products: List<Product>
    )

    private val secondaryMetricsFlow = combine(accounts, customers, suppliers, products) { a, c, sup, prod ->
        SecondaryMetrics(a, c, sup, prod)
    }

    // Dashboard metrics derived reactively
    val dashboardMetrics: StateFlow<DashboardMetrics> = combine(
        sales,
        purchases,
        expenses,
        secondaryMetricsFlow
    ) { sList, pList, eList, sec ->
        computeMetrics(sList, pList, eList, sec.accounts, sec.customers, sec.suppliers, sec.products)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardMetrics())

    init {
        // Evaluate PIN lock on launch
        viewModelScope.launch {
            val enabled = preferences.pinEnabledFlow.first()
            val hash = preferences.pinHashFlow.first()
            if (enabled && hash.isNotBlank()) {
                isAppUnlocked.value = false
            } else {
                isAppUnlocked.value = true
            }
        }
    }

    private fun computeMetrics(
        sales: List<Sale>,
        purchases: List<Purchase>,
        expenses: List<Expense>,
        accounts: List<Account>,
        customers: List<Customer>,
        suppliers: List<Supplier>,
        products: List<Product>
    ): DashboardMetrics {
        val activeSales = sales.filter { it.status == "ACTIVE" }

        val totalSales = activeSales.sumOf { it.grandTotal }
        val totalPurchases = purchases.sumOf { it.grandTotal }
        val totalExpenses = expenses.sumOf { it.amount }

        val totalCash = accounts.filter { it.accountType == "CASH" }.sumOf { it.balance }
        val totalBank = accounts.filter { it.accountType == "BANK" }.sumOf { it.balance }

        val totalCustomerDue = customers.sumOf { it.currentDue }
        val totalSupplierDue = suppliers.sumOf { it.currentPayable }

        val totalStockValue = products.sumOf { it.stockQuantity * it.purchasePrice }

        // Rough Cost of Goods Sold ratio or exact:
        // When selling price is given, COGS is approximated from product's average margin or purchase prices
        val avgMarginRatio = if (products.isNotEmpty()) {
            val totalSell = products.sumOf { it.sellingPrice }
            val totalCost = products.sumOf { it.purchasePrice }
            if (totalSell > 0) (totalSell - totalCost) / totalSell else 0.25
        } else 0.25
        val estimatedGrossProfit = totalSales * avgMarginRatio.coerceIn(0.05, 0.95)
        val totalProfit = estimatedGrossProfit - totalExpenses

        val now = System.currentTimeMillis()
        val startOfToday = Formatters.getStartOfDay(now)
        val startOfWeek = Formatters.getStartOfWeek(now)
        val startOfMonth = Formatters.getStartOfMonth(now)

        // Today
        val todaySalesList = activeSales.filter { it.date >= startOfToday }
        val todaySales = todaySalesList.sumOf { it.grandTotal }
        val todayPurchases = purchases.filter { it.date >= startOfToday }.sumOf { it.grandTotal }
        val todayExpenses = expenses.filter { it.date >= startOfToday }.sumOf { it.amount }
        val todayProfit = (todaySales * avgMarginRatio) - todayExpenses

        // Week
        val weekSalesList = activeSales.filter { it.date >= startOfWeek }
        val weekSales = weekSalesList.sumOf { it.grandTotal }
        val weekPurchases = purchases.filter { it.date >= startOfWeek }.sumOf { it.grandTotal }
        val weekExpenses = expenses.filter { it.date >= startOfWeek }.sumOf { it.amount }
        val weekProfit = (weekSales * avgMarginRatio) - weekExpenses

        // Month
        val monthSalesList = activeSales.filter { it.date >= startOfMonth }
        val monthSales = monthSalesList.sumOf { it.grandTotal }
        val monthPurchases = purchases.filter { it.date >= startOfMonth }.sumOf { it.grandTotal }
        val monthExpenses = expenses.filter { it.date >= startOfMonth }.sumOf { it.amount }
        val monthProfit = (monthSales * avgMarginRatio) - monthExpenses

        return DashboardMetrics(
            totalSales = totalSales,
            totalPurchases = totalPurchases,
            totalExpenses = totalExpenses,
            totalProfit = totalProfit,
            totalCash = totalCash,
            totalBank = totalBank,
            totalCustomerDue = totalCustomerDue,
            totalSupplierDue = totalSupplierDue,
            totalStockValue = totalStockValue,
            todaySales = todaySales,
            todayPurchases = todayPurchases,
            todayExpenses = todayExpenses,
            todayProfit = todayProfit,
            weekSales = weekSales,
            weekPurchases = weekPurchases,
            weekExpenses = weekExpenses,
            weekProfit = weekProfit,
            monthSales = monthSales,
            monthPurchases = monthPurchases,
            monthExpenses = monthExpenses,
            monthProfit = monthProfit
        )
    }

    // Party Actions
    fun saveCustomer(customer: Customer, onComplete: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = repository.saveCustomer(customer)
            onComplete(id)
        }
    }

    fun deleteCustomer(customer: Customer) {
        viewModelScope.launch {
            repository.deleteCustomer(customer)
        }
    }

    fun saveSupplier(supplier: Supplier, onComplete: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = repository.saveSupplier(supplier)
            onComplete(id)
        }
    }

    fun deleteSupplier(supplier: Supplier) {
        viewModelScope.launch {
            repository.deleteSupplier(supplier)
        }
    }

    // Inventory Actions
    fun saveProduct(product: Product, onComplete: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = repository.saveProduct(product)
            onComplete(id)
        }
    }

    fun deleteProduct(product: Product) {
        viewModelScope.launch {
            repository.deleteProduct(product)
        }
    }

    fun addCategory(name: String) {
        viewModelScope.launch {
            if (name.isNotBlank()) {
                repository.addCategory(name.trim())
            }
        }
    }

    fun deleteCategory(category: Category) {
        viewModelScope.launch {
            repository.deleteCategory(category)
        }
    }

    // Sales Actions
    fun createSale(
        sale: Sale,
        items: List<SaleItem>,
        onSuccess: (Long) -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            try {
                val allowNeg = allowNegativeStock.value
                val id = repository.createSale(sale, items, allowNeg)
                onSuccess(id)
            } catch (e: Exception) {
                onError(e.message ?: "Failed to create invoice")
            }
        }
    }

    fun cancelSale(saleId: Long, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val success = repository.cancelSale(saleId)
            onResult(success)
        }
    }

    // Purchase Actions
    fun createPurchase(
        purchase: Purchase,
        items: List<PurchaseItem>,
        onSuccess: (Long) -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            try {
                val id = repository.createPurchase(purchase, items)
                onSuccess(id)
            } catch (e: Exception) {
                onError(e.message ?: "Failed to record purchase")
            }
        }
    }

    // Payments
    fun recordCustomerPayment(
        customerId: Long,
        customerName: String,
        amount: Double,
        paymentMethod: String,
        accountId: Long,
        referenceNo: String,
        notes: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            repository.recordCustomerPayment(
                customerId,
                customerName,
                amount,
                paymentMethod,
                accountId,
                referenceNo,
                notes
            )
            onSuccess()
        }
    }

    fun recordSupplierPayment(
        supplierId: Long,
        supplierName: String,
        amount: Double,
        paymentMethod: String,
        accountId: Long,
        referenceNo: String,
        notes: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            repository.recordSupplierPayment(
                supplierId,
                supplierName,
                amount,
                paymentMethod,
                accountId,
                referenceNo,
                notes
            )
            onSuccess()
        }
    }

    // Expenses
    fun createExpense(expense: Expense, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.createExpense(expense)
            onSuccess()
        }
    }

    fun deleteExpense(expense: Expense) {
        viewModelScope.launch {
            repository.deleteExpense(expense)
        }
    }

    // Accounts
    fun transferBetweenAccounts(fromId: Long, toId: Long, amount: Double, notes: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.transferBetweenAccounts(fromId, toId, amount, notes)
            onSuccess()
        }
    }

    fun adjustCashDepositWithdrawal(isDeposit: Boolean, amount: Double, notes: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.adjustCashDepositWithdrawal(isDeposit, amount = amount, notes = notes)
            onSuccess()
        }
    }

    // Settings
    fun setCurrency(cur: AppCurrency) {
        viewModelScope.launch { preferences.setCurrency(cur) }
    }

    fun setLanguage(lang: AppLanguage) {
        viewModelScope.launch { preferences.setLanguage(lang) }
    }

    fun setPin(pin: String) {
        viewModelScope.launch { preferences.setPin(pin) }
    }

    fun setPinEnabled(enabled: Boolean) {
        viewModelScope.launch { preferences.setPinEnabled(enabled) }
    }

    fun setBusinessProfile(name: String, phone: String, address: String, note: String) {
        viewModelScope.launch {
            preferences.setBusinessProfile(name, phone, address, note)
        }
    }

    fun setAllowNegativeStock(allow: Boolean) {
        viewModelScope.launch {
            preferences.setAllowNegativeStock(allow)
        }
    }

    fun unlockApp(pin: String): Boolean {
        val hash = pinHash.value
        if (hash.isBlank()) {
            isAppUnlocked.value = true
            return true
        }
        val valid = preferences.verifyPin(pin, hash)
        if (valid) {
            isAppUnlocked.value = true
        }
        return valid
    }

    // Backup & Restore
    fun createBackup(onResult: (File?) -> Unit) {
        viewModelScope.launch {
            val file = BackupManager.createJsonBackup(getApplication(), db)
            onResult(file)
        }
    }

    fun restoreBackup(jsonContent: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val success = BackupManager.restoreFromJson(db, jsonContent)
            onResult(success)
        }
    }
}
