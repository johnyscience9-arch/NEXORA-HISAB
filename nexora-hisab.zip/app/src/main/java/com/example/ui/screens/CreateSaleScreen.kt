package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Customer
import com.example.data.model.Product
import com.example.data.model.Sale
import com.example.data.model.SaleItem
import com.example.ui.components.NexoraSearchField
import com.example.ui.theme.*
import com.example.ui.viewmodel.NexoraViewModel
import com.example.util.AppCurrency
import com.example.util.AppLanguage
import com.example.util.Formatters
import com.example.util.Localization

data class CartItem(
    val product: Product,
    var quantity: Double = 1.0,
    var unitPrice: Double = product.sellingPrice
) {
    val total: Double get() = quantity * unitPrice
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateSaleScreen(
    viewModel: NexoraViewModel,
    currency: AppCurrency,
    language: AppLanguage,
    onNavigateBack: () -> Unit
) {
    val customers by viewModel.customers.collectAsState()
    val products by viewModel.products.collectAsState()
    val accounts by viewModel.accounts.collectAsState()

    var selectedCustomer by remember { mutableStateOf<Customer?>(null) }
    var customerNameInput by remember { mutableStateOf("Walk-in Customer") }
    var customerPhoneInput by remember { mutableStateOf("") }
    var showCustomerPicker by remember { mutableStateOf(false) }

    var cartItems by remember { mutableStateOf<List<CartItem>>(emptyList()) }
    var showProductPicker by remember { mutableStateOf(false) }

    var discountInput by remember { mutableStateOf("") }
    var paidAmountInput by remember { mutableStateOf("") }
    var notesInput by remember { mutableStateOf("") }
    var selectedPaymentMethod by remember { mutableStateOf("CASH") } // CASH, BANK

    val subtotal = remember(cartItems) { cartItems.sumOf { it.total } }
    val discount = remember(discountInput) { discountInput.toDoubleOrNull() ?: 0.0 }
    val grandTotal = remember(subtotal, discount) { (subtotal - discount).coerceAtLeast(0.0) }
    val paidAmount = remember(paidAmountInput, grandTotal) {
        paidAmountInput.toDoubleOrNull() ?: grandTotal
    }
    val dueAmount = remember(grandTotal, paidAmount) { (grandTotal - paidAmount).coerceAtLeast(0.0) }

    val context = LocalContext.current

    Scaffold(
        containerColor = NexoraDarkBackground,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NexoraDarkSurface),
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("create_sale_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NexoraTextPrimary)
                    }
                },
                title = {
                    Text(
                        text = Localization.getString("create_sale", language),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraTextPrimary
                        )
                    )
                }
            )
        },
        bottomBar = {
            Surface(
                color = NexoraDarkSurface,
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = Localization.getString("grand_total", language), color = NexoraTextSecondary, fontSize = 12.sp)
                        Text(
                            text = Formatters.formatCurrency(grandTotal, currency),
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = NexoraCyanPrimary
                            )
                        )
                    }
                    Button(
                        onClick = {
                            if (cartItems.isEmpty()) {
                                Toast.makeText(context, "Please add at least one product", Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            val invoiceNumber = "INV-${System.currentTimeMillis().toString().takeLast(6)}"
                            val cashAcc = accounts.firstOrNull { it.accountType == "CASH" }
                            val bankAcc = accounts.firstOrNull { it.accountType == "BANK" }
                            val accountId = if (selectedPaymentMethod == "BANK") bankAcc?.id ?: 2L else cashAcc?.id ?: 1L

                            val sale = Sale(
                                invoiceNumber = invoiceNumber,
                                customerId = selectedCustomer?.id,
                                customerName = selectedCustomer?.name ?: customerNameInput.ifBlank { "Walk-in Customer" },
                                customerPhone = selectedCustomer?.phone ?: customerPhoneInput,
                                subtotal = subtotal,
                                discount = discount,
                                grandTotal = grandTotal,
                                paidAmount = paidAmount.coerceAtMost(grandTotal),
                                dueAmount = dueAmount,
                                paymentMethod = selectedPaymentMethod,
                                accountId = accountId,
                                date = System.currentTimeMillis(),
                                notes = notesInput
                            )

                            val saleItems = cartItems.map { item ->
                                SaleItem(
                                    saleId = 0L,
                                    productId = item.product.id,
                                    productName = item.product.name,
                                    productCode = item.product.code,
                                    quantity = item.quantity,
                                    unitPrice = item.unitPrice,
                                    purchasePriceAtSale = item.product.purchasePrice,
                                    total = item.total
                                )
                            }

                            viewModel.createSale(
                                sale = sale,
                                items = saleItems,
                                onSuccess = {
                                    Toast.makeText(context, "Invoice #$invoiceNumber Created!", Toast.LENGTH_SHORT).show()
                                    onNavigateBack()
                                },
                                onError = { error ->
                                    Toast.makeText(context, error, Toast.LENGTH_LONG).show()
                                }
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NexoraCyanPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("submit_create_sale_button")
                    ) {
                        Text(
                            text = Localization.getString("confirm", language),
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Customer Section Card
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = NexoraDarkSurface),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = Localization.getString("select_customer", language),
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = NexoraTextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            )
                            TextButton(
                                onClick = { showCustomerPicker = true },
                                modifier = Modifier.testTag("pick_customer_button")
                            ) {
                                Text("Select / Change", color = NexoraCyanPrimary, fontSize = 12.sp)
                            }
                        }

                        if (selectedCustomer != null) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = NexoraDarkSurfaceVariant,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = selectedCustomer!!.name,
                                            color = NexoraTextPrimary,
                                            fontWeight = FontWeight.Bold
                                        )
                                        if (selectedCustomer!!.phone.isNotBlank()) {
                                            Text(
                                                text = selectedCustomer!!.phone,
                                                color = NexoraTextSecondary,
                                                fontSize = 12.sp
                                            )
                                        }
                                        if (selectedCustomer!!.currentDue > 0) {
                                            Text(
                                                text = "Existing Due: ${Formatters.formatCurrency(selectedCustomer!!.currentDue, currency)}",
                                                color = NexoraCoralError,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                    IconButton(onClick = { selectedCustomer = null }) {
                                        Icon(Icons.Default.Close, contentDescription = "Clear", tint = NexoraTextMuted)
                                    }
                                }
                            }
                        } else {
                            OutlinedTextField(
                                value = customerNameInput,
                                onValueChange = { customerNameInput = it },
                                label = { Text(Localization.getString("name", language)) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = customerPhoneInput,
                                onValueChange = { customerPhoneInput = it },
                                label = { Text(Localization.getString("phone", language)) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }

            // 2. Added Items List
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${Localization.getString("inventory", language)} (${cartItems.size})",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = NexoraTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Button(
                        onClick = { showProductPicker = true },
                        colors = ButtonDefaults.buttonColors(containerColor = NexoraDarkSurfaceVariant),
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraCyanPrimary)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("add_product_to_invoice_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = NexoraCyanPrimary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(Localization.getString("add_products", language), color = NexoraCyanPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (cartItems.isEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = NexoraDarkSurface),
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showProductPicker = true }
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "+ Tap to Add Products from Inventory",
                                color = NexoraCyanPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            } else {
                items(cartItems) { item ->
                    CartItemRow(
                        item = item,
                        currency = currency,
                        onQuantityChange = { newQty ->
                            if (newQty <= 0) {
                                cartItems = cartItems.filter { it.product.id != item.product.id }
                            } else {
                                cartItems = cartItems.map {
                                    if (it.product.id == item.product.id) it.copy(quantity = newQty) else it
                                }
                            }
                        },
                        onUnitPriceChange = { newPrice ->
                            cartItems = cartItems.map {
                                if (it.product.id == item.product.id) it.copy(unitPrice = newPrice) else it
                            }
                        },
                        onRemove = {
                            cartItems = cartItems.filter { it.product.id != item.product.id }
                        }
                    )
                }
            }

            // 3. Totals and Payment Breakdown
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = NexoraDarkSurface),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(Localization.getString("subtotal", language), color = NexoraTextSecondary)
                            Text(Formatters.formatCurrency(subtotal, currency), color = NexoraTextPrimary, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(12.dp))

                        // Discount Field
                        OutlinedTextField(
                            value = discountInput,
                            onValueChange = { discountInput = it },
                            label = { Text(Localization.getString("discount", language)) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = NexoraDarkBorder)
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(Localization.getString("grand_total", language), color = NexoraTextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(Formatters.formatCurrency(grandTotal, currency), color = NexoraCyanPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Paid Amount with Quick Buttons
                        Text(text = Localization.getString("paid_amount", language), color = NexoraTextSecondary, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(4.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { paidAmountInput = grandTotal.toString() },
                                colors = ButtonDefaults.buttonColors(containerColor = NexoraDarkSurfaceVariant),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Full Paid", color = NexoraEmeraldSuccess, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = { paidAmountInput = "0" },
                                colors = ButtonDefaults.buttonColors(containerColor = NexoraDarkSurfaceVariant),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Full Due", color = NexoraCoralError, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = paidAmountInput,
                            onValueChange = { paidAmountInput = it },
                            placeholder = { Text(grandTotal.toString()) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        if (dueAmount > 0) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(Localization.getString("due_amount", language), color = NexoraCoralError, fontWeight = FontWeight.Bold)
                                Text(Formatters.formatCurrency(dueAmount, currency), color = NexoraCoralError, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Payment Method Selector (CASH / BANK)
                        Text(text = Localization.getString("payment_method", language), color = NexoraTextSecondary, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = selectedPaymentMethod == "CASH",
                                onClick = { selectedPaymentMethod = "CASH" },
                                label = { Text(Localization.getString("cash_account", language)) },
                                modifier = Modifier.weight(1f)
                            )
                            FilterChip(
                                selected = selectedPaymentMethod == "BANK",
                                onClick = { selectedPaymentMethod = "BANK" },
                                label = { Text(Localization.getString("bank_account", language)) },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Notes Field
                        OutlinedTextField(
                            value = notesInput,
                            onValueChange = { notesInput = it },
                            label = { Text(Localization.getString("notes", language)) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }

    // Customer Picker Dialog
    if (showCustomerPicker) {
        var custSearch by remember { mutableStateOf("") }
        val filteredCust = remember(customers, custSearch) {
            if (custSearch.isBlank()) customers
            else customers.filter { it.name.contains(custSearch, ignoreCase = true) || it.phone.contains(custSearch) }
        }

        AlertDialog(
            onDismissRequest = { showCustomerPicker = false },
            containerColor = NexoraDarkSurfaceVariant,
            title = { Text(Localization.getString("customers", language), color = NexoraTextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth().heightIn(max = 350.dp)) {
                    NexoraSearchField(query = custSearch, onQueryChange = { custSearch = it }, placeholder = "Search customer...")
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        item {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = NexoraDarkSurface,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedCustomer = null
                                        customerNameInput = "Walk-in Customer"
                                        showCustomerPicker = false
                                    }
                            ) {
                                Text(
                                    text = "Walk-in Customer (General)",
                                    color = NexoraCyanPrimary,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }
                        items(filteredCust) { c ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = NexoraDarkSurface,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedCustomer = c
                                        customerNameInput = c.name
                                        customerPhoneInput = c.phone
                                        showCustomerPicker = false
                                    }
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(text = c.name, color = NexoraTextPrimary, fontWeight = FontWeight.Bold)
                                    if (c.phone.isNotBlank()) Text(text = c.phone, color = NexoraTextMuted, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showCustomerPicker = false }) {
                    Text("Close", color = NexoraTextSecondary)
                }
            }
        )
    }

    // Product Picker Dialog
    if (showProductPicker) {
        var prodSearch by remember { mutableStateOf("") }
        val filteredProds = remember(products, prodSearch) {
            if (prodSearch.isBlank()) products
            else products.filter { it.name.contains(prodSearch, ignoreCase = true) || it.code.contains(prodSearch) }
        }

        AlertDialog(
            onDismissRequest = { showProductPicker = false },
            containerColor = NexoraDarkSurfaceVariant,
            title = { Text(Localization.getString("add_products", language), color = NexoraTextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth().heightIn(max = 400.dp)) {
                    NexoraSearchField(query = prodSearch, onQueryChange = { prodSearch = it }, placeholder = "Search products...")
                    Spacer(modifier = Modifier.height(10.dp))
                    if (filteredProds.isEmpty()) {
                        Text(text = "No products found in inventory. Go to Inventory tab to add products first.", color = NexoraTextMuted, fontSize = 13.sp)
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(filteredProds) { prod ->
                                val alreadyInCart = cartItems.any { it.product.id == prod.id }
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = NexoraDarkSurface,
                                    border = if (alreadyInCart) CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraCyanPrimary)) else null,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            if (!alreadyInCart) {
                                                cartItems = cartItems + CartItem(product = prod)
                                            }
                                            showProductPicker = false
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(text = prod.name, color = NexoraTextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            Text(
                                                text = "Stock: ${Formatters.formatQuantity(prod.stockQuantity, prod.unit)}  |  Price: ${Formatters.formatCurrency(prod.sellingPrice, currency)}",
                                                color = NexoraTextSecondary,
                                                fontSize = 11.sp
                                            )
                                        }
                                        Icon(
                                            imageVector = if (alreadyInCart) Icons.Default.CheckCircle else Icons.Default.AddCircle,
                                            contentDescription = null,
                                            tint = if (alreadyInCart) NexoraEmeraldSuccess else NexoraCyanPrimary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showProductPicker = false }) {
                    Text("Close", color = NexoraTextSecondary)
                }
            }
        )
    }
}

@Composable
fun CartItemRow(
    item: CartItem,
    currency: AppCurrency,
    onQuantityChange: (Double) -> Unit,
    onUnitPriceChange: (Double) -> Unit,
    onRemove: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NexoraDarkSurface),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.product.name,
                        color = NexoraTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "Rate: ${Formatters.formatCurrency(item.unitPrice, currency)} / ${item.product.unit}",
                        color = NexoraTextMuted,
                        fontSize = 11.sp
                    )
                }
                IconButton(onClick = onRemove) {
                    Icon(Icons.Default.Delete, contentDescription = "Remove", tint = NexoraCoralError, modifier = Modifier.size(20.dp))
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Quantity Stepper
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { onQuantityChange(item.quantity - 1.0) },
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(NexoraDarkSurfaceVariant)
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Minus", tint = NexoraTextPrimary, modifier = Modifier.size(16.dp))
                    }
                    Text(
                        text = Formatters.formatQuantity(item.quantity, ""),
                        color = NexoraTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    IconButton(
                        onClick = { onQuantityChange(item.quantity + 1.0) },
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(NexoraDarkSurfaceVariant)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Plus", tint = NexoraTextPrimary, modifier = Modifier.size(16.dp))
                    }
                }

                // Line Total
                Text(
                    text = Formatters.formatCurrency(item.total, currency),
                    color = NexoraCyanPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }
    }
}
