package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Product
import com.example.data.model.Purchase
import com.example.data.model.PurchaseItem
import com.example.data.model.Supplier
import com.example.ui.components.NexoraSearchField
import com.example.ui.theme.*
import com.example.ui.viewmodel.NexoraViewModel
import com.example.util.AppCurrency
import com.example.util.AppLanguage
import com.example.util.Formatters
import com.example.util.Localization

data class PurchaseCartItem(
    val product: Product,
    var quantity: Double = 1.0,
    var unitPrice: Double = product.purchasePrice
) {
    val total: Double get() = quantity * unitPrice
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreatePurchaseScreen(
    viewModel: NexoraViewModel,
    currency: AppCurrency,
    language: AppLanguage,
    onNavigateBack: () -> Unit
) {
    val suppliers by viewModel.suppliers.collectAsState()
    val products by viewModel.products.collectAsState()
    val accounts by viewModel.accounts.collectAsState()

    var selectedSupplier by remember { mutableStateOf<Supplier?>(null) }
    var supplierNameInput by remember { mutableStateOf("") }
    var showSupplierPicker by remember { mutableStateOf(false) }

    var cartItems by remember { mutableStateOf<List<PurchaseCartItem>>(emptyList()) }
    var showProductPicker by remember { mutableStateOf(false) }

    var paidAmountInput by remember { mutableStateOf("") }
    var notesInput by remember { mutableStateOf("") }
    var selectedPaymentMethod by remember { mutableStateOf("CASH") }

    val grandTotal = remember(cartItems) { cartItems.sumOf { it.total } }
    val paidAmount = remember(paidAmountInput, grandTotal) {
        paidAmountInput.toDoubleOrNull() ?: grandTotal
    }
    val remainingPayable = remember(grandTotal, paidAmount) { (grandTotal - paidAmount).coerceAtLeast(0.0) }

    val context = LocalContext.current

    Scaffold(
        containerColor = NexoraDarkBackground,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NexoraDarkSurface),
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("create_purchase_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NexoraTextPrimary)
                    }
                },
                title = {
                    Text(
                        text = Localization.getString("create_purchase", language),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraTextPrimary
                        )
                    )
                }
            )
        },
        bottomBar = {
            Surface(
                color = NexoraDarkSurface,
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = Localization.getString("grand_total", language), color = NexoraTextSecondary, fontSize = 12.sp)
                        Text(
                            text = Formatters.formatCurrency(grandTotal, currency),
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = NexoraTealAccent
                            )
                        )
                    }
                    Button(
                        onClick = {
                            if (cartItems.isEmpty()) {
                                Toast.makeText(context, "Please add at least one product", Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            val invoiceNumber = "PUR-${System.currentTimeMillis().toString().takeLast(6)}"
                            val cashAcc = accounts.firstOrNull { it.accountType == "CASH" }
                            val bankAcc = accounts.firstOrNull { it.accountType == "BANK" }
                            val accountId = if (selectedPaymentMethod == "BANK") bankAcc?.id ?: 2L else cashAcc?.id ?: 1L

                            val purchase = Purchase(
                                invoiceNumber = invoiceNumber,
                                supplierId = selectedSupplier?.id,
                                supplierName = selectedSupplier?.name ?: supplierNameInput.ifBlank { "Vendor" },
                                supplierPhone = selectedSupplier?.phone ?: "",
                                subtotal = grandTotal,
                                grandTotal = grandTotal,
                                paidAmount = paidAmount.coerceAtMost(grandTotal),
                                remainingPayable = remainingPayable,
                                paymentMethod = selectedPaymentMethod,
                                accountId = accountId,
                                date = System.currentTimeMillis(),
                                notes = notesInput
                            )

                            val purchaseItems = cartItems.map { item ->
                                PurchaseItem(
                                    purchaseId = 0L,
                                    productId = item.product.id,
                                    productName = item.product.name,
                                    quantity = item.quantity,
                                    unitPrice = item.unitPrice,
                                    total = item.total
                                )
                            }

                            viewModel.createPurchase(
                                purchase = purchase,
                                items = purchaseItems,
                                onSuccess = {
                                    Toast.makeText(context, "Purchase #$invoiceNumber Recorded & Stock Updated!", Toast.LENGTH_SHORT).show()
                                    onNavigateBack()
                                },
                                onError = { error ->
                                    Toast.makeText(context, error, Toast.LENGTH_LONG).show()
                                }
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NexoraTealAccent),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("submit_create_purchase_button")
                    ) {
                        Text(
                            text = Localization.getString("confirm", language),
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Supplier Section
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = NexoraDarkSurface),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = Localization.getString("select_supplier", language),
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = NexoraTextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            )
                            TextButton(
                                onClick = { showSupplierPicker = true },
                                modifier = Modifier.testTag("pick_supplier_button")
                            ) {
                                Text("Select / Change", color = NexoraTealAccent, fontSize = 12.sp)
                            }
                        }

                        if (selectedSupplier != null) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = NexoraDarkSurfaceVariant,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(text = selectedSupplier!!.name, color = NexoraTextPrimary, fontWeight = FontWeight.Bold)
                                        if (selectedSupplier!!.phone.isNotBlank()) {
                                            Text(text = selectedSupplier!!.phone, color = NexoraTextSecondary, fontSize = 12.sp)
                                        }
                                        if (selectedSupplier!!.currentPayable > 0) {
                                            Text(
                                                text = "Current Payable: ${Formatters.formatCurrency(selectedSupplier!!.currentPayable, currency)}",
                                                color = NexoraGoldAmber,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                    IconButton(onClick = { selectedSupplier = null }) {
                                        Icon(Icons.Default.Close, contentDescription = "Clear", tint = NexoraTextMuted)
                                    }
                                }
                            }
                        } else {
                            OutlinedTextField(
                                value = supplierNameInput,
                                onValueChange = { supplierNameInput = it },
                                label = { Text("Supplier / Vendor Name") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }

            // 2. Products Restocked
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Products (${cartItems.size})",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = NexoraTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Button(
                        onClick = { showProductPicker = true },
                        colors = ButtonDefaults.buttonColors(containerColor = NexoraDarkSurfaceVariant),
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraTealAccent)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("add_product_to_purchase_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = NexoraTealAccent, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(Localization.getString("add_products", language), color = NexoraTealAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (cartItems.isEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = NexoraDarkSurface),
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showProductPicker = true }
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "+ Tap to Add Restock Products",
                                color = NexoraTealAccent,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            } else {
                items(cartItems) { item ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = NexoraDarkSurface),
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = item.product.name,
                                    color = NexoraTextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                IconButton(onClick = { cartItems = cartItems.filter { it.product.id != item.product.id } }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Remove", tint = NexoraCoralError, modifier = Modifier.size(20.dp))
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = {
                                            val newQty = item.quantity - 1.0
                                            if (newQty <= 0) cartItems = cartItems.filter { it.product.id != item.product.id }
                                            else cartItems = cartItems.map { if (it.product.id == item.product.id) it.copy(quantity = newQty) else it }
                                        },
                                        modifier = Modifier.size(32.dp).clip(CircleShape).background(NexoraDarkSurfaceVariant)
                                    ) {
                                        Icon(Icons.Default.Remove, contentDescription = null, tint = NexoraTextPrimary, modifier = Modifier.size(16.dp))
                                    }
                                    Text(
                                        text = "${Formatters.formatQuantity(item.quantity, "")} ${item.product.unit}",
                                        color = NexoraTextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 10.dp)
                                    )
                                    IconButton(
                                        onClick = {
                                            val newQty = item.quantity + 1.0
                                            cartItems = cartItems.map { if (it.product.id == item.product.id) it.copy(quantity = newQty) else it }
                                        },
                                        modifier = Modifier.size(32.dp).clip(CircleShape).background(NexoraDarkSurfaceVariant)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null, tint = NexoraTextPrimary, modifier = Modifier.size(16.dp))
                                    }
                                }

                                Text(
                                    text = Formatters.formatCurrency(item.total, currency),
                                    color = NexoraTealAccent,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            }
                        }
                    }
                }
            }

            // 3. Purchase Payment Breakdown
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = NexoraDarkSurface),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Purchase Amount", color = NexoraTextPrimary, fontWeight = FontWeight.Bold)
                            Text(Formatters.formatCurrency(grandTotal, currency), color = NexoraTealAccent, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        Text(text = Localization.getString("paid_amount", language), color = NexoraTextSecondary, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(4.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { paidAmountInput = grandTotal.toString() },
                                colors = ButtonDefaults.buttonColors(containerColor = NexoraDarkSurfaceVariant),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Full Paid", color = NexoraEmeraldSuccess, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = { paidAmountInput = "0" },
                                colors = ButtonDefaults.buttonColors(containerColor = NexoraDarkSurfaceVariant),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Full Payable", color = NexoraGoldAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = paidAmountInput,
                            onValueChange = { paidAmountInput = it },
                            placeholder = { Text(grandTotal.toString()) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        if (remainingPayable > 0) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(Localization.getString("remaining_payable", language), color = NexoraGoldAmber, fontWeight = FontWeight.Bold)
                                Text(Formatters.formatCurrency(remainingPayable, currency), color = NexoraGoldAmber, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Payment Method
                        Text(text = Localization.getString("payment_method", language), color = NexoraTextSecondary, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = selectedPaymentMethod == "CASH",
                                onClick = { selectedPaymentMethod = "CASH" },
                                label = { Text(Localization.getString("cash_account", language)) },
                                modifier = Modifier.weight(1f)
                            )
                            FilterChip(
                                selected = selectedPaymentMethod == "BANK",
                                onClick = { selectedPaymentMethod = "BANK" },
                                label = { Text(Localization.getString("bank_account", language)) },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = notesInput,
                            onValueChange = { notesInput = it },
                            label = { Text(Localization.getString("notes", language)) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }

    // Supplier Picker
    if (showSupplierPicker) {
        AlertDialog(
            onDismissRequest = { showSupplierPicker = false },
            containerColor = NexoraDarkSurfaceVariant,
            title = { Text(Localization.getString("suppliers", language), color = NexoraTextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth().heightIn(max = 350.dp)) {
                    if (suppliers.isEmpty()) {
                        Text("No suppliers registered. Add one from Parties tab or type vendor name above.", color = NexoraTextMuted)
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(suppliers) { sup ->
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = NexoraDarkSurface,
                                    modifier = Modifier.fillMaxWidth().clickable {
                                        selectedSupplier = sup
                                        supplierNameInput = sup.name
                                        showSupplierPicker = false
                                    }
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(text = sup.name, color = NexoraTextPrimary, fontWeight = FontWeight.Bold)
                                        if (sup.phone.isNotBlank()) Text(text = sup.phone, color = NexoraTextMuted, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showSupplierPicker = false }) { Text("Close", color = NexoraTextSecondary) }
            }
        )
    }

    // Product Picker
    if (showProductPicker) {
        AlertDialog(
            onDismissRequest = { showProductPicker = false },
            containerColor = NexoraDarkSurfaceVariant,
            title = { Text(Localization.getString("add_products", language), color = NexoraTextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth().heightIn(max = 350.dp)) {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(products) { prod ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = NexoraDarkSurface,
                                modifier = Modifier.fillMaxWidth().clickable {
                                    if (!cartItems.any { it.product.id == prod.id }) {
                                        cartItems = cartItems + PurchaseCartItem(product = prod)
                                    }
                                    showProductPicker = false
                                }
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(text = prod.name, color = NexoraTextPrimary, fontWeight = FontWeight.Bold)
                                        Text(
                                            text = "Cost: ${Formatters.formatCurrency(prod.purchasePrice, currency)}",
                                            color = NexoraTextMuted,
                                            fontSize = 11.sp
                                        )
                                    }
                                    Icon(Icons.Default.AddCircle, contentDescription = null, tint = NexoraTealAccent)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showProductPicker = false }) { Text("Close", color = NexoraTextSecondary) }
            }
        )
    }
}
