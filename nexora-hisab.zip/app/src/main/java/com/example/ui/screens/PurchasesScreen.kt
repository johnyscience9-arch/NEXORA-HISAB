package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Purchase
import com.example.data.model.PurchaseItem
import com.example.ui.components.EmptyStateView
import com.example.ui.components.NexoraSearchField
import com.example.ui.theme.*
import com.example.ui.viewmodel.NexoraViewModel
import com.example.util.AppCurrency
import com.example.util.AppLanguage
import com.example.util.Formatters
import com.example.util.Localization

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PurchasesScreen(
    viewModel: NexoraViewModel,
    currency: AppCurrency,
    language: AppLanguage,
    onNavigateToCreatePurchase: () -> Unit
) {
    val purchases by viewModel.purchases.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var selectedPurchaseForDetail by remember { mutableStateOf<Purchase?>(null) }

    val filteredPurchases = remember(purchases, searchQuery) {
        if (searchQuery.isBlank()) purchases
        else purchases.filter {
            it.invoiceNumber.contains(searchQuery, ignoreCase = true) ||
            it.supplierName.contains(searchQuery, ignoreCase = true)
        }
    }

    Scaffold(
        containerColor = NexoraDarkBackground,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NexoraDarkSurface),
                title = {
                    Text(
                        text = Localization.getString("purchases", language),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraTextPrimary
                        )
                    )
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onNavigateToCreatePurchase,
                containerColor = NexoraTealAccent,
                contentColor = Color.Black,
                icon = { Icon(Icons.Default.AddShoppingCart, contentDescription = null) },
                text = { Text(Localization.getString("new_purchase", language), fontWeight = FontWeight.Bold) },
                modifier = Modifier
                    .navigationBarsPadding()
                    .testTag("create_purchase_fab")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))
            NexoraSearchField(
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                placeholder = "Search purchase invoice # or supplier..."
            )
            Spacer(modifier = Modifier.height(12.dp))

            if (filteredPurchases.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.Inventory,
                    title = Localization.getString("no_data", language),
                    message = "No purchase records logged yet. Add your purchases to increase product stock.",
                    actionLabel = Localization.getString("create_purchase", language),
                    onActionClick = onNavigateToCreatePurchase
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(bottom = 90.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredPurchases, key = { it.id }) { purchase ->
                        PurchaseCard(
                            purchase = purchase,
                            currency = currency,
                            onClick = { selectedPurchaseForDetail = purchase }
                        )
                    }
                }
            }
        }
    }

    // Purchase Detail Dialog
    selectedPurchaseForDetail?.let { purchase ->
        var purchaseItems by remember { mutableStateOf<List<PurchaseItem>>(emptyList()) }
        LaunchedEffect(purchase.id) {
            purchaseItems = viewModel.repository.getPurchaseItemsList(purchase.id)
        }

        AlertDialog(
            onDismissRequest = { selectedPurchaseForDetail = null },
            containerColor = NexoraDarkSurfaceVariant,
            title = {
                Column {
                    Text(text = "Purchase #${purchase.invoiceNumber}", color = NexoraTextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(text = Formatters.formatDateTime(purchase.date), color = NexoraTextMuted, fontSize = 12.sp)
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(text = "Supplier: ${purchase.supplierName}", color = NexoraTextPrimary, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = NexoraDarkBorder)
                    Spacer(modifier = Modifier.height(8.dp))

                    Text(text = "Items Restocked:", color = NexoraTealAccent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))

                    purchaseItems.forEach { item ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "${item.quantity}x ${item.productName}", color = NexoraTextPrimary, fontSize = 13.sp)
                            Text(text = Formatters.formatCurrency(item.total, currency), color = NexoraTextSecondary, fontSize = 13.sp)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = NexoraDarkBorder)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = Localization.getString("grand_total", language), color = NexoraTextPrimary, fontWeight = FontWeight.Bold)
                        Text(text = Formatters.formatCurrency(purchase.grandTotal, currency), color = NexoraTextPrimary, fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = Localization.getString("paid_amount", language), color = NexoraEmeraldSuccess)
                        Text(text = Formatters.formatCurrency(purchase.paidAmount, currency), color = NexoraEmeraldSuccess)
                    }
                    if (purchase.remainingPayable > 0) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = Localization.getString("remaining_payable", language), color = NexoraGoldAmber, fontWeight = FontWeight.Bold)
                            Text(text = Formatters.formatCurrency(purchase.remainingPayable, currency), color = NexoraGoldAmber, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedPurchaseForDetail = null }) {
                    Text("Close", color = NexoraCyanPrimary)
                }
            }
        )
    }
}

@Composable
fun PurchaseCard(
    purchase: Purchase,
    currency: AppCurrency,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = NexoraDarkSurface),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("purchase_card_${purchase.invoiceNumber}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(NexoraTealAccent.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Inventory2,
                            contentDescription = null,
                            tint = NexoraTealAccent,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "#${purchase.invoiceNumber}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = NexoraTextPrimary,
                                fontSize = 14.sp
                            )
                        )
                        Text(
                            text = Formatters.formatDateTime(purchase.date),
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = NexoraTextMuted,
                                fontSize = 11.sp
                            )
                        )
                    }
                }
                Text(
                    text = Formatters.formatCurrency(purchase.grandTotal, currency),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NexoraTextPrimary,
                        fontSize = 16.sp
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = NexoraDarkBorder)
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = purchase.supplierName.ifBlank { "Direct Vendor" },
                    color = NexoraTextSecondary,
                    fontSize = 13.sp
                )
                if (purchase.remainingPayable > 0) {
                    Text(
                        text = "Payable: ${Formatters.formatCurrency(purchase.remainingPayable, currency)}",
                        color = NexoraGoldAmber,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Text(
                        text = "Fully Paid",
                        color = NexoraEmeraldSuccess,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}
