package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Sale
import com.example.data.model.SaleItem
import com.example.ui.components.ConfirmationDialog
import com.example.ui.components.EmptyStateView
import com.example.ui.components.NexoraSearchField
import com.example.ui.theme.*
import com.example.ui.viewmodel.BusinessProfile
import com.example.ui.viewmodel.NexoraViewModel
import com.example.util.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SalesScreen(
    viewModel: NexoraViewModel,
    currency: AppCurrency,
    language: AppLanguage,
    businessProfile: BusinessProfile,
    onNavigateToCreateSale: () -> Unit
) {
    val sales by viewModel.sales.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var selectedSaleForDetail by remember { mutableStateOf<Sale?>(null) }
    var saleToCancel by remember { mutableStateOf<Sale?>(null) }

    val filteredSales = remember(sales, searchQuery) {
        if (searchQuery.isBlank()) sales
        else sales.filter {
            it.invoiceNumber.contains(searchQuery, ignoreCase = true) ||
            it.customerName.contains(searchQuery, ignoreCase = true)
        }
    }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    Scaffold(
        containerColor = NexoraDarkBackground,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NexoraDarkSurface),
                title = {
                    Text(
                        text = Localization.getString("sales", language),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraTextPrimary
                        )
                    )
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onNavigateToCreateSale,
                containerColor = NexoraCyanPrimary,
                contentColor = Color.Black,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text(Localization.getString("new_sale", language), fontWeight = FontWeight.Bold) },
                modifier = Modifier
                    .navigationBarsPadding()
                    .testTag("create_sale_fab")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))
            NexoraSearchField(
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                placeholder = "Search invoice # or customer..."
            )
            Spacer(modifier = Modifier.height(12.dp))

            if (filteredSales.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.ReceiptLong,
                    title = Localization.getString("no_data", language),
                    message = "No sales invoices created yet. Tap below to create your first invoice.",
                    actionLabel = Localization.getString("create_sale", language),
                    onActionClick = onNavigateToCreateSale
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(bottom = 90.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredSales, key = { it.id }) { sale ->
                        SaleInvoiceCard(
                            sale = sale,
                            currency = currency,
                            language = language,
                            onClick = { selectedSaleForDetail = sale }
                        )
                    }
                }
            }
        }
    }

    // Invoice Detail Dialog
    selectedSaleForDetail?.let { sale ->
        var saleItems by remember { mutableStateOf<List<SaleItem>>(emptyList()) }
        LaunchedEffect(sale.id) {
            saleItems = viewModel.repository.getSaleItemsList(sale.id)
        }

        AlertDialog(
            onDismissRequest = { selectedSaleForDetail = null },
            containerColor = NexoraDarkSurfaceVariant,
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Invoice #${sale.invoiceNumber}",
                            color = NexoraTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = Formatters.formatDateTime(sale.date),
                            color = NexoraTextMuted,
                            fontSize = 12.sp
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (sale.status == "ACTIVE") NexoraEmeraldSuccess.copy(alpha = 0.15f) else NexoraCoralError.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = sale.status,
                            color = if (sale.status == "ACTIVE") NexoraEmeraldSuccess else NexoraCoralError,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Customer: ${sale.customerName}",
                        color = NexoraTextPrimary,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp
                    )
                    if (sale.customerPhone.isNotBlank()) {
                        Text(
                            text = "Phone: ${sale.customerPhone}",
                            color = NexoraTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = NexoraDarkBorder)
                    Spacer(modifier = Modifier.height(8.dp))

                    Text(text = "Items:", color = NexoraCyanPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))

                    saleItems.forEach { item ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${item.quantity}x ${item.productName}",
                                color = NexoraTextPrimary,
                                fontSize = 13.sp,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = Formatters.formatCurrency(item.total, currency),
                                color = NexoraTextSecondary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = NexoraDarkBorder)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = Localization.getString("subtotal", language), color = NexoraTextSecondary, fontSize = 13.sp)
                        Text(text = Formatters.formatCurrency(sale.subtotal, currency), color = NexoraTextPrimary, fontSize = 13.sp)
                    }
                    if (sale.discount > 0) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = Localization.getString("discount", language), color = NexoraGoldAmber, fontSize = 13.sp)
                            Text(text = "-${Formatters.formatCurrency(sale.discount, currency)}", color = NexoraGoldAmber, fontSize = 13.sp)
                        }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = Localization.getString("grand_total", language), color = NexoraTextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(text = Formatters.formatCurrency(sale.grandTotal, currency), color = NexoraTextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = Localization.getString("paid_amount", language), color = NexoraEmeraldSuccess, fontSize = 13.sp)
                        Text(text = Formatters.formatCurrency(sale.paidAmount, currency), color = NexoraEmeraldSuccess, fontSize = 13.sp)
                    }
                    if (sale.dueAmount > 0) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = Localization.getString("due_amount", language), color = NexoraCoralError, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(text = Formatters.formatCurrency(sale.dueAmount, currency), color = NexoraCoralError, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Share PDF Button
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                val file = PdfInvoiceGenerator.generateAndShareInvoice(
                                    context = context,
                                    sale = sale,
                                    items = saleItems,
                                    businessName = businessProfile.name,
                                    businessPhone = businessProfile.phone,
                                    businessAddress = businessProfile.address,
                                    invoiceNote = businessProfile.invoiceNote,
                                    currency = currency
                                )
                                if (file != null) {
                                    PdfInvoiceGenerator.sharePdf(context, file)
                                } else {
                                    Toast.makeText(context, "Could not create PDF", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NexoraCyanPrimary),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("share_pdf_button")
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("PDF", color = Color.Black, fontWeight = FontWeight.Bold)
                    }

                    // Cancel invoice button if active
                    if (sale.status == "ACTIVE") {
                        OutlinedButton(
                            onClick = {
                                saleToCancel = sale
                                selectedSaleForDetail = null
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = NexoraCoralError),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("cancel_sale_button")
                        ) {
                            Text("Cancel", color = NexoraCoralError)
                        }
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedSaleForDetail = null }) {
                    Text("Close", color = NexoraTextSecondary)
                }
            }
        )
    }

    // Cancel Sale Confirmation
    saleToCancel?.let { sale ->
        ConfirmationDialog(
            title = Localization.getString("cancel_invoice", language),
            message = "Cancelling Invoice #${sale.invoiceNumber} will restore product inventory and reverse customer due and received payments.",
            confirmText = "Yes, Cancel Invoice",
            cancelText = Localization.getString("cancel", language),
            isDestructive = true,
            onConfirm = {
                viewModel.cancelSale(sale.id) { success ->
                    if (success) {
                        Toast.makeText(context, "Invoice #${sale.invoiceNumber} cancelled", Toast.LENGTH_SHORT).show()
                    }
                }
                saleToCancel = null
            },
            onDismiss = { saleToCancel = null }
        )
    }
}

@Composable
fun SaleInvoiceCard(
    sale: Sale,
    currency: AppCurrency,
    language: AppLanguage,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = NexoraDarkSurface),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("invoice_card_${sale.invoiceNumber}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(NexoraCyanPrimary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Receipt,
                            contentDescription = null,
                            tint = NexoraCyanPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "#${sale.invoiceNumber}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = NexoraTextPrimary,
                                fontSize = 14.sp
                            )
                        )
                        Text(
                            text = Formatters.formatDateTime(sale.date),
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = NexoraTextMuted,
                                fontSize = 11.sp
                            )
                        )
                    }
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (sale.status == "ACTIVE") NexoraEmeraldSuccess.copy(alpha = 0.12f) else NexoraCoralError.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = sale.status,
                        color = if (sale.status == "ACTIVE") NexoraEmeraldSuccess else NexoraCoralError,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = NexoraDarkBorder)
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = sale.customerName,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = NexoraTextSecondary,
                            fontWeight = FontWeight.Medium,
                            fontSize = 13.sp
                        )
                    )
                    Text(
                        text = "Paid: ${Formatters.formatCurrency(sale.paidAmount, currency)}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NexoraEmeraldSuccess,
                            fontSize = 11.sp
                        )
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = Formatters.formatCurrency(sale.grandTotal, currency),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraTextPrimary,
                            fontSize = 16.sp
                        )
                    )
                    if (sale.dueAmount > 0) {
                        Text(
                            text = "Due: ${Formatters.formatCurrency(sale.dueAmount, currency)}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = NexoraCoralError,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        )
                    }
                }
            }
        }
    }
}
