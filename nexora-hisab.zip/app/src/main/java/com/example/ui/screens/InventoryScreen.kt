package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Product
import com.example.ui.components.ConfirmationDialog
import com.example.ui.components.EmptyStateView
import com.example.ui.components.NexoraSearchField
import com.example.ui.theme.*
import com.example.ui.viewmodel.NexoraViewModel
import com.example.util.AppCurrency
import com.example.util.AppLanguage
import com.example.util.Formatters
import com.example.util.Localization

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InventoryScreen(
    viewModel: NexoraViewModel,
    currency: AppCurrency,
    language: AppLanguage
) {
    val products by viewModel.products.collectAsState()
    val categories by viewModel.categories.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategoryFilter by remember { mutableStateOf("All") }
    var showLowStockOnly by remember { mutableStateOf(false) }

    var productToEdit by remember { mutableStateOf<Product?>(null) }
    var showAddEditDialog by remember { mutableStateOf(false) }
    var productToDelete by remember { mutableStateOf<Product?>(null) }

    val filteredProducts = remember(products, searchQuery, selectedCategoryFilter, showLowStockOnly) {
        products.filter { p ->
            val matchQuery = searchQuery.isBlank() || p.name.contains(searchQuery, ignoreCase = true) || p.code.contains(searchQuery, ignoreCase = true)
            val matchCategory = selectedCategoryFilter == "All" || p.category == selectedCategoryFilter
            val matchLowStock = !showLowStockOnly || p.stockQuantity <= p.lowStockAlert
            matchQuery && matchCategory && matchLowStock
        }
    }

    val totalItemsCount = products.size
    val totalStockValuationCost = remember(products) { products.sumOf { it.stockQuantity * it.purchasePrice } }
    val totalStockValuationRetail = remember(products) { products.sumOf { it.stockQuantity * it.sellingPrice } }

    val context = LocalContext.current

    Scaffold(
        containerColor = NexoraDarkBackground,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NexoraDarkSurface),
                title = {
                    Text(
                        text = Localization.getString("inventory", language),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraTextPrimary
                        )
                    )
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    productToEdit = null
                    showAddEditDialog = true
                },
                containerColor = NexoraCyanPrimary,
                contentColor = Color.Black,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text(Localization.getString("add_product", language), fontWeight = FontWeight.Bold) },
                modifier = Modifier
                    .navigationBarsPadding()
                    .testTag("add_product_fab")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            // Stock Valuation Summary Card
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = NexoraDarkSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(Localization.getString("stock_value", language), color = NexoraTextSecondary, fontSize = 11.sp)
                        Text(
                            text = Formatters.formatCurrency(totalStockValuationCost, currency),
                            color = NexoraCyanPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Items: $totalItemsCount", color = NexoraTextMuted, fontSize = 11.sp)
                        Text(
                            text = "Retail: ${Formatters.formatCurrency(totalStockValuationRetail, currency)}",
                            color = NexoraGoldAmber,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Search Bar
            NexoraSearchField(
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                placeholder = "Search product by name or SKU..."
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Filter Chips (Categories & Low Stock)
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 4.dp)
            ) {
                item {
                    FilterChip(
                        selected = !showLowStockOnly && selectedCategoryFilter == "All",
                        onClick = {
                            selectedCategoryFilter = "All"
                            showLowStockOnly = false
                        },
                        label = { Text("All Products") }
                    )
                }
                item {
                    FilterChip(
                        selected = showLowStockOnly,
                        onClick = { showLowStockOnly = !showLowStockOnly },
                        label = { Text(Localization.getString("low_stock_badge", language)) },
                        leadingIcon = {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = NexoraCoralError, modifier = Modifier.size(16.dp))
                        }
                    )
                }
                items(categories) { cat ->
                    FilterChip(
                        selected = selectedCategoryFilter == cat.name && !showLowStockOnly,
                        onClick = {
                            selectedCategoryFilter = cat.name
                            showLowStockOnly = false
                        },
                        label = { Text(cat.name) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (filteredProducts.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.Inventory2,
                    title = Localization.getString("no_data", language),
                    message = "No matching products found in stock.",
                    actionLabel = Localization.getString("add_product", language),
                    onActionClick = {
                        productToEdit = null
                        showAddEditDialog = true
                    }
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(bottom = 90.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredProducts, key = { it.id }) { product ->
                        ProductItemCard(
                            product = product,
                            currency = currency,
                            language = language,
                            onEdit = {
                                productToEdit = product
                                showAddEditDialog = true
                            },
                            onDelete = {
                                productToDelete = product
                            }
                        )
                    }
                }
            }
        }
    }

    // Add / Edit Product Dialog
    if (showAddEditDialog) {
        AddEditProductDialog(
            product = productToEdit,
            currency = currency,
            language = language,
            onDismiss = { showAddEditDialog = false },
            onSave = { product ->
                viewModel.saveProduct(product) {
                    Toast.makeText(context, "Product Saved!", Toast.LENGTH_SHORT).show()
                }
                showAddEditDialog = false
            }
        )
    }

    // Delete Confirmation Dialog
    productToDelete?.let { prod ->
        ConfirmationDialog(
            title = Localization.getString("confirm_delete", language),
            message = "Are you sure you want to delete '${prod.name}' from your inventory?",
            confirmText = Localization.getString("delete", language),
            cancelText = Localization.getString("cancel", language),
            isDestructive = true,
            onConfirm = {
                viewModel.deleteProduct(prod)
                Toast.makeText(context, "Product deleted", Toast.LENGTH_SHORT).show()
                productToDelete = null
            },
            onDismiss = { productToDelete = null }
        )
    }
}

@Composable
fun ProductItemCard(
    product: Product,
    currency: AppCurrency,
    language: AppLanguage,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val isLowStock = product.stockQuantity <= product.lowStockAlert
    val isOutOfStock = product.stockQuantity <= 0

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = NexoraDarkSurface),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("product_card_${product.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = product.name,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = NexoraTextPrimary,
                                fontSize = 15.sp
                            )
                        )
                        if (product.code.isNotBlank()) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = NexoraDarkSurfaceVariant
                            ) {
                                Text(
                                    text = product.code,
                                    color = NexoraTextMuted,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    Text(
                        text = "Category: ${product.category}",
                        color = NexoraTextSecondary,
                        fontSize = 12.sp
                    )
                }

                Row {
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit", tint = NexoraCyanPrimary, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = NexoraCoralError, modifier = Modifier.size(18.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = NexoraDarkBorder)
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Sell: ${Formatters.formatCurrency(product.sellingPrice, currency)}",
                        color = NexoraEmeraldSuccess,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "Cost: ${Formatters.formatCurrency(product.purchasePrice, currency)}",
                        color = NexoraTextMuted,
                        fontSize = 11.sp
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "Stock: ${Formatters.formatQuantity(product.stockQuantity, product.unit)}",
                        color = if (isOutOfStock) NexoraCoralError else if (isLowStock) NexoraGoldAmber else NexoraTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    if (isOutOfStock) {
                        Text(
                            text = Localization.getString("out_of_stock", language),
                            color = NexoraCoralError,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    } else if (isLowStock) {
                        Text(
                            text = Localization.getString("low_stock_badge", language),
                            color = NexoraGoldAmber,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AddEditProductDialog(
    product: Product?,
    currency: AppCurrency,
    language: AppLanguage,
    onDismiss: () -> Unit,
    onSave: (Product) -> Unit
) {
    var name by remember { mutableStateOf(product?.name ?: "") }
    var code by remember { mutableStateOf(product?.code ?: "") }
    var category by remember { mutableStateOf(product?.category ?: "General") }
    var purchasePriceInput by remember { mutableStateOf(product?.purchasePrice?.toString() ?: "") }
    var sellingPriceInput by remember { mutableStateOf(product?.sellingPrice?.toString() ?: "") }
    var stockQuantityInput by remember { mutableStateOf(product?.stockQuantity?.toString() ?: "0") }
    var unit by remember { mutableStateOf(product?.unit ?: "pcs") }
    var lowStockAlertInput by remember { mutableStateOf(product?.lowStockAlert?.toString() ?: "5") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NexoraDarkSurfaceVariant,
        title = {
            Text(
                text = if (product == null) Localization.getString("add_product", language) else Localization.getString("edit_product", language),
                color = NexoraTextPrimary,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text(Localization.getString("product_name", language)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    OutlinedTextField(
                        value = code,
                        onValueChange = { code = it },
                        label = { Text(Localization.getString("sku", language)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = { Text(Localization.getString("category", language)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = purchasePriceInput,
                            onValueChange = { purchasePriceInput = it },
                            label = { Text("Cost Price (${currency.symbol})") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = sellingPriceInput,
                            onValueChange = { sellingPriceInput = it },
                            label = { Text("Sell Price (${currency.symbol})") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = stockQuantityInput,
                            onValueChange = { stockQuantityInput = it },
                            label = { Text(Localization.getString("stock_qty", language)) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = unit,
                            onValueChange = { unit = it },
                            label = { Text("Unit (pcs/kg)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                item {
                    OutlinedTextField(
                        value = lowStockAlertInput,
                        onValueChange = { lowStockAlertInput = it },
                        label = { Text(Localization.getString("low_stock_alert", language)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) return@Button
                    val pPrice = purchasePriceInput.toDoubleOrNull() ?: 0.0
                    val sPrice = sellingPriceInput.toDoubleOrNull() ?: 0.0
                    val qty = stockQuantityInput.toDoubleOrNull() ?: 0.0
                    val lowAlert = lowStockAlertInput.toDoubleOrNull() ?: 5.0

                    val newProd = Product(
                        id = product?.id ?: 0L,
                        name = name.trim(),
                        code = code.trim(),
                        category = category.trim().ifBlank { "General" },
                        purchasePrice = pPrice,
                        sellingPrice = sPrice,
                        stockQuantity = qty,
                        unit = unit.trim().ifBlank { "pcs" },
                        lowStockAlert = lowAlert,
                        createdAt = product?.createdAt ?: System.currentTimeMillis()
                    )
                    onSave(newProd)
                },
                colors = ButtonDefaults.buttonColors(containerColor = NexoraCyanPrimary),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("save_product_button")
            ) {
                Text(Localization.getString("save", language), color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(Localization.getString("cancel", language), color = NexoraTextSecondary)
            }
        }
    )
}
