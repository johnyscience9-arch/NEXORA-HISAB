package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.local.AppDatabase
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

class NexoraRepository(private val db: AppDatabase) {

    private val customerDao = db.customerDao()
    private val supplierDao = db.supplierDao()
    private val productDao = db.productDao()
    private val categoryDao = db.categoryDao()
    private val saleDao = db.saleDao()
    private val purchaseDao = db.purchaseDao()
    private val paymentDao = db.paymentDao()
    private val expenseDao = db.expenseDao()
    private val accountDao = db.accountDao()

    // Customers
    val allCustomers: Flow<List<Customer>> = customerDao.getAllCustomers()
    fun searchCustomers(query: String): Flow<List<Customer>> = customerDao.searchCustomers(query)
    suspend fun getCustomerById(id: Long): Customer? = customerDao.getCustomerById(id)
    suspend fun saveCustomer(customer: Customer): Long {
        return if (customer.id == 0L) {
            customerDao.insertCustomer(customer.copy(currentDue = customer.openingBalance))
        } else {
            customerDao.updateCustomer(customer)
            customer.id
        }
    }
    suspend fun deleteCustomer(customer: Customer) = customerDao.deleteCustomer(customer)

    // Suppliers
    val allSuppliers: Flow<List<Supplier>> = supplierDao.getAllSuppliers()
    fun searchSuppliers(query: String): Flow<List<Supplier>> = supplierDao.searchSuppliers(query)
    suspend fun getSupplierById(id: Long): Supplier? = supplierDao.getSupplierById(id)
    suspend fun saveSupplier(supplier: Supplier): Long {
        return if (supplier.id == 0L) {
            supplierDao.insertSupplier(supplier.copy(currentPayable = supplier.openingBalance))
        } else {
            supplierDao.updateSupplier(supplier)
            supplier.id
        }
    }
    suspend fun deleteSupplier(supplier: Supplier) = supplierDao.deleteSupplier(supplier)

    // Products
    val allProducts: Flow<List<Product>> = productDao.getAllProducts()
    val lowStockProducts: Flow<List<Product>> = productDao.getLowStockProducts()
    fun searchProducts(query: String): Flow<List<Product>> = productDao.searchProducts(query)
    suspend fun getProductById(id: Long): Product? = productDao.getProductById(id)
    suspend fun saveProduct(product: Product): Long {
        return if (product.id == 0L) {
            productDao.insertProduct(product)
        } else {
            productDao.updateProduct(product)
            product.id
        }
    }
    suspend fun deleteProduct(product: Product) = productDao.deleteProduct(product)
    suspend fun adjustProductStock(id: Long, qtyChange: Double) = productDao.adjustStock(id, qtyChange)

    // Categories
    val allCategories: Flow<List<Category>> = categoryDao.getAllCategories()
    suspend fun addCategory(name: String) = categoryDao.insertCategory(Category(name = name))
    suspend fun deleteCategory(category: Category) = categoryDao.deleteCategory(category)

    // Accounts
    val allAccounts: Flow<List<Account>> = accountDao.getAllAccounts()
    val recentTransactions: Flow<List<AccountTransaction>> = accountDao.getRecentTransactions(50)
    fun getAccountTransactions(accountId: Long): Flow<List<AccountTransaction>> = accountDao.getTransactionsForAccount(accountId)

    suspend fun saveAccount(account: Account): Long {
        return if (account.id == 0L) {
            accountDao.insertAccount(account)
        } else {
            accountDao.updateAccount(account)
            account.id
        }
    }

    // Sales
    val allSales: Flow<List<Sale>> = saleDao.getAllSales()
    fun getSalesByDateRange(startDate: Long, endDate: Long): Flow<List<Sale>> = saleDao.getSalesByDateRange(startDate, endDate)
    fun getSalesByCustomer(customerId: Long): Flow<List<Sale>> = saleDao.getSalesByCustomer(customerId)
    suspend fun getSaleById(id: Long): Sale? = saleDao.getSaleById(id)
    fun getSaleItems(saleId: Long): Flow<List<SaleItem>> = saleDao.getSaleItems(saleId)
    suspend fun getSaleItemsList(saleId: Long): List<SaleItem> = saleDao.getSaleItemsList(saleId)

    suspend fun createSale(
        sale: Sale,
        items: List<SaleItem>,
        allowNegativeStock: Boolean = false
    ): Long = db.withTransaction {
        // Validate stock if negative not allowed
        if (!allowNegativeStock) {
            for (item in items) {
                val p = productDao.getProductById(item.productId)
                if (p != null && (p.stockQuantity - item.quantity) < 0) {
                    throw IllegalStateException("Insufficient stock for product: ${p.name}. Available: ${p.stockQuantity}")
                }
            }
        }

        // 1. Insert Sale
        val saleId = saleDao.insertSale(sale)

        // 2. Insert items and decrement stock
        val itemsWithSaleId = items.map { it.copy(saleId = saleId) }
        saleDao.insertSaleItems(itemsWithSaleId)

        for (item in items) {
            productDao.adjustStock(item.productId, -item.quantity)
        }

        // 3. Update customer due if applicable
        if (sale.dueAmount > 0 && sale.customerId != null && sale.customerId > 0) {
            customerDao.adjustDue(sale.customerId, sale.dueAmount)
        }

        // 4. Update Cash/Bank account for paid amount
        if (sale.paidAmount > 0) {
            val accId = sale.accountId ?: 1L // Default to Cash in Hand
            accountDao.adjustAccountBalance(accId, sale.paidAmount)
            val acc = accountDao.getAccountById(accId)
            accountDao.insertTransaction(
                AccountTransaction(
                    accountId = accId,
                    type = "SALE_PAYMENT",
                    amount = sale.paidAmount,
                    balanceAfter = acc?.balance ?: 0.0,
                    referenceId = saleId,
                    date = sale.date,
                    description = "Sale #${sale.invoiceNumber} payment (${sale.customerName})"
                )
            )
        }

        saleId
    }

    suspend fun cancelSale(saleId: Long): Boolean = db.withTransaction {
        val sale = saleDao.getSaleById(saleId) ?: return@withTransaction false
        if (sale.status == "CANCELLED") return@withTransaction false

        // 1. Restore product quantities
        val items = saleDao.getSaleItemsList(saleId)
        for (item in items) {
            productDao.adjustStock(item.productId, item.quantity)
        }

        // 2. Reverse customer due if was added
        if (sale.dueAmount > 0 && sale.customerId != null && sale.customerId > 0) {
            customerDao.adjustDue(sale.customerId, -sale.dueAmount)
        }

        // 3. Reverse cash/bank balance if was paid
        if (sale.paidAmount > 0) {
            val accId = sale.accountId ?: 1L
            accountDao.adjustAccountBalance(accId, -sale.paidAmount)
            val acc = accountDao.getAccountById(accId)
            accountDao.insertTransaction(
                AccountTransaction(
                    accountId = accId,
                    type = "SALE_REVERSAL",
                    amount = -sale.paidAmount,
                    balanceAfter = acc?.balance ?: 0.0,
                    referenceId = saleId,
                    date = System.currentTimeMillis(),
                    description = "Cancelled Sale #${sale.invoiceNumber} refund"
                )
            )
        }

        // 4. Update status
        saleDao.updateSaleStatus(saleId, "CANCELLED")
        true
    }

    // Purchases
    val allPurchases: Flow<List<Purchase>> = purchaseDao.getAllPurchases()
    fun getPurchasesByDateRange(startDate: Long, endDate: Long): Flow<List<Purchase>> = purchaseDao.getPurchasesByDateRange(startDate, endDate)
    fun getPurchasesBySupplier(supplierId: Long): Flow<List<Purchase>> = purchaseDao.getPurchasesBySupplier(supplierId)
    suspend fun getPurchaseById(id: Long): Purchase? = purchaseDao.getPurchaseById(id)
    fun getPurchaseItems(purchaseId: Long): Flow<List<PurchaseItem>> = purchaseDao.getPurchaseItems(purchaseId)
    suspend fun getPurchaseItemsList(purchaseId: Long): List<PurchaseItem> = purchaseDao.getPurchaseItemsList(purchaseId)

    suspend fun createPurchase(
        purchase: Purchase,
        items: List<PurchaseItem>
    ): Long = db.withTransaction {
        // 1. Insert Purchase
        val purchaseId = purchaseDao.insertPurchase(purchase)

        // 2. Insert items and increment product stock
        val itemsWithId = items.map { it.copy(purchaseId = purchaseId) }
        purchaseDao.insertPurchaseItems(itemsWithId)

        for (item in items) {
            productDao.adjustStock(item.productId, item.quantity)
            // Optionally update purchase price on product for latest cost
            val p = productDao.getProductById(item.productId)
            if (p != null) {
                productDao.updateProduct(p.copy(purchasePrice = item.unitPrice))
            }
        }

        // 3. Update supplier payable if applicable
        if (purchase.remainingPayable > 0 && purchase.supplierId != null && purchase.supplierId > 0) {
            supplierDao.adjustPayable(purchase.supplierId, purchase.remainingPayable)
        }

        // 4. Deduct paid amount from Cash/Bank account
        if (purchase.paidAmount > 0) {
            val accId = purchase.accountId ?: 1L
            accountDao.adjustAccountBalance(accId, -purchase.paidAmount)
            val acc = accountDao.getAccountById(accId)
            accountDao.insertTransaction(
                AccountTransaction(
                    accountId = accId,
                    type = "PURCHASE_PAYMENT",
                    amount = -purchase.paidAmount,
                    balanceAfter = acc?.balance ?: 0.0,
                    referenceId = purchaseId,
                    date = purchase.date,
                    description = "Purchase #${purchase.invoiceNumber} to ${purchase.supplierName}"
                )
            )
        }

        purchaseId
    }

    // Payments (Customer / Supplier)
    val allPayments: Flow<List<Payment>> = paymentDao.getAllPayments()
    fun getPaymentsByParty(partyType: String, partyId: Long): Flow<List<Payment>> = paymentDao.getPaymentsByParty(partyType, partyId)
    fun getPaymentsByDateRange(startDate: Long, endDate: Long): Flow<List<Payment>> = paymentDao.getPaymentsByDateRange(startDate, endDate)

    suspend fun recordCustomerPayment(
        customerId: Long,
        customerName: String,
        amount: Double,
        paymentMethod: String,
        accountId: Long,
        referenceNo: String,
        notes: String
    ): Long = db.withTransaction {
        val payment = Payment(
            partyType = "CUSTOMER",
            partyId = customerId,
            partyName = customerName,
            amount = amount,
            paymentMethod = paymentMethod,
            accountId = accountId,
            referenceNumber = referenceNo,
            notes = notes
        )
        val paymentId = paymentDao.insertPayment(payment)

        // Decrement customer due
        customerDao.adjustDue(customerId, -amount)

        // Increment account balance
        accountDao.adjustAccountBalance(accountId, amount)
        val acc = accountDao.getAccountById(accountId)
        accountDao.insertTransaction(
            AccountTransaction(
                accountId = accountId,
                type = "CUSTOMER_PAYMENT",
                amount = amount,
                balanceAfter = acc?.balance ?: 0.0,
                referenceId = paymentId,
                date = payment.date,
                description = "Received from Customer: $customerName"
            )
        )

        paymentId
    }

    suspend fun recordSupplierPayment(
        supplierId: Long,
        supplierName: String,
        amount: Double,
        paymentMethod: String,
        accountId: Long,
        referenceNo: String,
        notes: String
    ): Long = db.withTransaction {
        val payment = Payment(
            partyType = "SUPPLIER",
            partyId = supplierId,
            partyName = supplierName,
            amount = amount,
            paymentMethod = paymentMethod,
            accountId = accountId,
            referenceNumber = referenceNo,
            notes = notes
        )
        val paymentId = paymentDao.insertPayment(payment)

        // Decrement supplier payable
        supplierDao.adjustPayable(supplierId, -amount)

        // Deduct from account balance
        accountDao.adjustAccountBalance(accountId, -amount)
        val acc = accountDao.getAccountById(accountId)
        accountDao.insertTransaction(
            AccountTransaction(
                accountId = accountId,
                type = "SUPPLIER_PAYMENT",
                amount = -amount,
                balanceAfter = acc?.balance ?: 0.0,
                referenceId = paymentId,
                date = payment.date,
                description = "Paid to Supplier: $supplierName"
            )
        )

        paymentId
    }

    // Expenses
    val allExpenses: Flow<List<Expense>> = expenseDao.getAllExpenses()
    fun getExpensesByDateRange(startDate: Long, endDate: Long): Flow<List<Expense>> = expenseDao.getExpensesByDateRange(startDate, endDate)

    suspend fun createExpense(expense: Expense): Long = db.withTransaction {
        val expenseId = expenseDao.insertExpense(expense)

        // Deduct from account
        accountDao.adjustAccountBalance(expense.accountId, -expense.amount)
        val acc = accountDao.getAccountById(expense.accountId)
        accountDao.insertTransaction(
            AccountTransaction(
                accountId = expense.accountId,
                type = "EXPENSE",
                amount = -expense.amount,
                balanceAfter = acc?.balance ?: 0.0,
                referenceId = expenseId,
                date = expense.date,
                description = "Expense: [${expense.category}] ${expense.notes}"
            )
        )

        expenseId
    }

    suspend fun deleteExpense(expense: Expense) = db.withTransaction {
        // Reverse account balance
        accountDao.adjustAccountBalance(expense.accountId, expense.amount)
        val acc = accountDao.getAccountById(expense.accountId)
        accountDao.insertTransaction(
            AccountTransaction(
                accountId = expense.accountId,
                type = "EXPENSE_REVERSAL",
                amount = expense.amount,
                balanceAfter = acc?.balance ?: 0.0,
                referenceId = expense.id,
                date = System.currentTimeMillis(),
                description = "Reversal of deleted expense: [${expense.category}]"
            )
        )
        expenseDao.deleteExpense(expense)
    }

    // Cash & Bank Transfers
    suspend fun transferBetweenAccounts(
        fromAccountId: Long,
        toAccountId: Long,
        amount: Double,
        notes: String
    ) = db.withTransaction {
        // Deduct from source
        accountDao.adjustAccountBalance(fromAccountId, -amount)
        val fromAcc = accountDao.getAccountById(fromAccountId)
        accountDao.insertTransaction(
            AccountTransaction(
                accountId = fromAccountId,
                type = "TRANSFER_OUT",
                amount = -amount,
                balanceAfter = fromAcc?.balance ?: 0.0,
                date = System.currentTimeMillis(),
                description = "Transfer to ${toAccountId}: $notes"
            )
        )

        // Add to destination
        accountDao.adjustAccountBalance(toAccountId, amount)
        val toAcc = accountDao.getAccountById(toAccountId)
        accountDao.insertTransaction(
            AccountTransaction(
                accountId = toAccountId,
                type = "TRANSFER_IN",
                amount = amount,
                balanceAfter = toAcc?.balance ?: 0.0,
                date = System.currentTimeMillis(),
                description = "Transfer from ${fromAccountId}: $notes"
            )
        )
    }

    suspend fun adjustCashDepositWithdrawal(
        isDeposit: Boolean, // true = deposit cash to bank, false = withdraw bank to cash
        cashAccountId: Long = 1,
        bankAccountId: Long = 2,
        amount: Double,
        notes: String
    ) {
        if (isDeposit) {
            transferBetweenAccounts(cashAccountId, bankAccountId, amount, if (notes.isNotBlank()) notes else "Cash deposit to bank")
        } else {
            transferBetweenAccounts(bankAccountId, cashAccountId, amount, if (notes.isNotBlank()) notes else "Cash withdrawal from bank")
        }
    }
}
