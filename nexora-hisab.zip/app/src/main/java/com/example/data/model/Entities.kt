package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
    val address: String = "",
    val openingBalance: Double = 0.0,
    val currentDue: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "suppliers")
data class Supplier(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
    val address: String = "",
    val openingBalance: Double = 0.0,
    val currentPayable: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "categories")
data class Category(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String
)

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val code: String = "",
    val category: String = "General",
    val purchasePrice: Double = 0.0,
    val sellingPrice: Double = 0.0,
    val stockQuantity: Double = 0.0,
    val unit: String = "pcs",
    val lowStockAlert: Double = 5.0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "sales")
data class Sale(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val invoiceNumber: String,
    val customerId: Long? = null,
    val customerName: String = "Walk-in Customer",
    val customerPhone: String = "",
    val subtotal: Double = 0.0,
    val discount: Double = 0.0,
    val grandTotal: Double = 0.0,
    val paidAmount: Double = 0.0,
    val dueAmount: Double = 0.0,
    val paymentMethod: String = "CASH", // CASH, BANK, DUE
    val accountId: Long? = null,
    val status: String = "ACTIVE", // ACTIVE, CANCELLED
    val date: Long = System.currentTimeMillis(),
    val notes: String = ""
)

@Entity(tableName = "sale_items")
data class SaleItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val productId: Long,
    val productName: String,
    val productCode: String = "",
    val quantity: Double,
    val unitPrice: Double,
    val purchasePriceAtSale: Double, // Cost of goods sold for exact profit calculation
    val total: Double
)

@Entity(tableName = "purchases")
data class Purchase(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val invoiceNumber: String,
    val supplierId: Long? = null,
    val supplierName: String = "",
    val supplierPhone: String = "",
    val subtotal: Double = 0.0,
    val grandTotal: Double = 0.0,
    val paidAmount: Double = 0.0,
    val remainingPayable: Double = 0.0,
    val paymentMethod: String = "CASH", // CASH, BANK, PAYABLE
    val accountId: Long? = null,
    val date: Long = System.currentTimeMillis(),
    val notes: String = ""
)

@Entity(tableName = "purchase_items")
data class PurchaseItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val purchaseId: Long,
    val productId: Long,
    val productName: String,
    val quantity: Double,
    val unitPrice: Double,
    val total: Double
)

@Entity(tableName = "payments")
data class Payment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val partyType: String, // "CUSTOMER" (received money), "SUPPLIER" (paid money)
    val partyId: Long,
    val partyName: String,
    val amount: Double,
    val paymentMethod: String = "CASH",
    val accountId: Long = 1,
    val referenceNumber: String = "",
    val date: Long = System.currentTimeMillis(),
    val notes: String = ""
)

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String,
    val amount: Double,
    val paymentMethod: String = "CASH",
    val accountId: Long = 1,
    val date: Long = System.currentTimeMillis(),
    val notes: String = ""
)

@Entity(tableName = "accounts")
data class Account(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val accountType: String = "CASH", // CASH, BANK
    val accountNumber: String = "",
    val balance: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "account_transactions")
data class AccountTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val accountId: Long,
    val type: String, // DEPOSIT, WITHDRAWAL, TRANSFER_IN, TRANSFER_OUT, SALE_PAYMENT, PURCHASE_PAYMENT, EXPENSE, CUSTOMER_PAYMENT, SUPPLIER_PAYMENT, OPENING_BALANCE
    val amount: Double,
    val balanceAfter: Double,
    val referenceId: Long? = null,
    val date: Long = System.currentTimeMillis(),
    val description: String = ""
)
