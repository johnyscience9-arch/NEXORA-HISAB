package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        Customer::class,
        Supplier::class,
        Category::class,
        Product::class,
        Sale::class,
        SaleItem::class,
        Purchase::class,
        PurchaseItem::class,
        Payment::class,
        Expense::class,
        Account::class,
        AccountTransaction::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun customerDao(): CustomerDao
    abstract fun supplierDao(): SupplierDao
    abstract fun productDao(): ProductDao
    abstract fun categoryDao(): CategoryDao
    abstract fun saleDao(): SaleDao
    abstract fun purchaseDao(): PurchaseDao
    abstract fun paymentDao(): PaymentDao
    abstract fun expenseDao(): ExpenseDao
    abstract fun accountDao(): AccountDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "nexora_hisab.db"
                )
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Seed default accounts and standard categories (clean, zero balances)
                        CoroutineScope(Dispatchers.IO).launch {
                            val database = getDatabase(context)
                            val accountDao = database.accountDao()
                            accountDao.insertAccount(
                                Account(
                                    id = 1,
                                    name = "Cash in Hand (হাতে নগদ)",
                                    accountType = "CASH",
                                    balance = 0.0
                                )
                            )
                            accountDao.insertAccount(
                                Account(
                                    id = 2,
                                    name = "Bank Account (ব্যাংক হিসাব)",
                                    accountType = "BANK",
                                    balance = 0.0
                                )
                            )

                            val categoryDao = database.categoryDao()
                            val defaultCategories = listOf(
                                "General",
                                "Groceries",
                                "Electronics",
                                "Clothing",
                                "Hardware",
                                "Medicine",
                                "Stationery"
                            )
                            defaultCategories.forEach { catName ->
                                categoryDao.insertCategory(Category(name = catName))
                            }
                        }
                    }
                })
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
