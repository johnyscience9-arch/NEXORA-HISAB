package com.example.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.util.AppCurrency
import com.example.util.AppLanguage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "nexora_settings")

class AppPreferences(private val context: Context) {

    companion object {
        val KEY_CURRENCY = stringPreferencesKey("app_currency")
        val KEY_LANGUAGE = stringPreferencesKey("app_language")
        val KEY_PIN_ENABLED = booleanPreferencesKey("pin_enabled")
        val KEY_PIN_HASH = stringPreferencesKey("pin_hash")
        val KEY_BUSINESS_NAME = stringPreferencesKey("business_name")
        val KEY_BUSINESS_PHONE = stringPreferencesKey("business_phone")
        val KEY_BUSINESS_ADDRESS = stringPreferencesKey("business_address")
        val KEY_INVOICE_NOTE = stringPreferencesKey("invoice_note")
        val KEY_ALLOW_NEGATIVE_STOCK = booleanPreferencesKey("allow_negative_stock")
    }

    val currencyFlow: Flow<AppCurrency> = context.dataStore.data.map { prefs ->
        val code = prefs[KEY_CURRENCY] ?: AppCurrency.BDT.code
        try { AppCurrency.valueOf(code) } catch (e: Exception) { AppCurrency.BDT }
    }

    val languageFlow: Flow<AppLanguage> = context.dataStore.data.map { prefs ->
        val code = prefs[KEY_LANGUAGE] ?: AppLanguage.BENGALI.code
        if (code == AppLanguage.ENGLISH.code) AppLanguage.ENGLISH else AppLanguage.BENGALI
    }

    val pinEnabledFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_PIN_ENABLED] ?: false
    }

    val pinHashFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_PIN_HASH] ?: ""
    }

    val businessNameFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_BUSINESS_NAME] ?: "Nexora Enterprise"
    }

    val businessPhoneFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_BUSINESS_PHONE] ?: "+880 1700-000000"
    }

    val businessAddressFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_BUSINESS_ADDRESS] ?: "Dhaka, Bangladesh"
    }

    val invoiceNoteFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_INVOICE_NOTE] ?: "Thank you for doing business with us!"
    }

    val allowNegativeStockFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_ALLOW_NEGATIVE_STOCK] ?: false
    }

    suspend fun setCurrency(currency: AppCurrency) {
        context.dataStore.edit { it[KEY_CURRENCY] = currency.code }
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { it[KEY_LANGUAGE] = language.code }
    }

    suspend fun setPin(pin: String) {
        val hash = hashPin(pin)
        context.dataStore.edit {
            it[KEY_PIN_HASH] = hash
            it[KEY_PIN_ENABLED] = pin.isNotBlank()
        }
    }

    suspend fun setPinEnabled(enabled: Boolean) {
        context.dataStore.edit { it[KEY_PIN_ENABLED] = enabled }
    }

    suspend fun setBusinessProfile(name: String, phone: String, address: String, note: String) {
        context.dataStore.edit {
            it[KEY_BUSINESS_NAME] = name
            it[KEY_BUSINESS_PHONE] = phone
            it[KEY_BUSINESS_ADDRESS] = address
            it[KEY_INVOICE_NOTE] = note
        }
    }

    suspend fun setAllowNegativeStock(allow: Boolean) {
        context.dataStore.edit { it[KEY_ALLOW_NEGATIVE_STOCK] = allow }
    }

    fun hashPin(pin: String): String {
        return java.security.MessageDigest.getInstance("SHA-256")
            .digest(pin.toByteArray())
            .joinToString("") { "%02x".format(it) }
    }

    fun verifyPin(enteredPin: String, storedHash: String): Boolean {
        if (storedHash.isBlank()) return true
        return hashPin(enteredPin) == storedHash
    }
}
