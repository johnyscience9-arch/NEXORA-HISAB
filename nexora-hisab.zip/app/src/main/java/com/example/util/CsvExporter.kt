package com.example.util

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.example.data.model.*
import java.io.File
import java.io.FileWriter

object CsvExporter {

    fun exportSalesCsv(context: Context, sales: List<Sale>): File? {
        return try {
            val dir = File(context.cacheDir, "reports").apply { mkdirs() }
            val file = File(dir, "sales_report_${System.currentTimeMillis()}.csv")
            FileWriter(file).use { writer ->
                writer.append("Invoice No,Date,Customer Name,Phone,Subtotal,Discount,Grand Total,Paid Amount,Due Amount,Payment Method,Status\n")
                for (s in sales) {
                    writer.append("\"${s.invoiceNumber}\",")
                    writer.append("\"${Formatters.formatDateTime(s.date)}\",")
                    writer.append("\"${s.customerName.replace("\"", "\"\"")}\",")
                    writer.append("\"${s.customerPhone}\",")
                    writer.append("${s.subtotal},")
                    writer.append("${s.discount},")
                    writer.append("${s.grandTotal},")
                    writer.append("${s.paidAmount},")
                    writer.append("${s.dueAmount},")
                    writer.append("\"${s.paymentMethod}\",")
                    writer.append("\"${s.status}\"\n")
                }
            }
            file
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun exportPurchasesCsv(context: Context, purchases: List<Purchase>): File? {
        return try {
            val dir = File(context.cacheDir, "reports").apply { mkdirs() }
            val file = File(dir, "purchases_report_${System.currentTimeMillis()}.csv")
            FileWriter(file).use { writer ->
                writer.append("Invoice No,Date,Supplier Name,Subtotal,Grand Total,Paid Amount,Remaining Payable,Payment Method\n")
                for (p in purchases) {
                    writer.append("\"${p.invoiceNumber}\",")
                    writer.append("\"${Formatters.formatDateTime(p.date)}\",")
                    writer.append("\"${p.supplierName.replace("\"", "\"\"")}\",")
                    writer.append("${p.subtotal},")
                    writer.append("${p.grandTotal},")
                    writer.append("${p.paidAmount},")
                    writer.append("${p.remainingPayable},")
                    writer.append("\"${p.paymentMethod}\"\n")
                }
            }
            file
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun exportInventoryCsv(context: Context, products: List<Product>): File? {
        return try {
            val dir = File(context.cacheDir, "reports").apply { mkdirs() }
            val file = File(dir, "inventory_report_${System.currentTimeMillis()}.csv")
            FileWriter(file).use { writer ->
                writer.append("Product Name,SKU,Category,Purchase Price,Selling Price,Stock Qty,Unit,Stock Value (Purchase Cost),Potential Value (Selling Price)\n")
                for (p in products) {
                    val purchaseVal = p.stockQuantity * p.purchasePrice
                    val sellVal = p.stockQuantity * p.sellingPrice
                    writer.append("\"${p.name.replace("\"", "\"\"")}\",")
                    writer.append("\"${p.code}\",")
                    writer.append("\"${p.category}\",")
                    writer.append("${p.purchasePrice},")
                    writer.append("${p.sellingPrice},")
                    writer.append("${p.stockQuantity},")
                    writer.append("\"${p.unit}\",")
                    writer.append("$purchaseVal,")
                    writer.append("$sellVal\n")
                }
            }
            file
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun exportCustomersCsv(context: Context, customers: List<Customer>): File? {
        return try {
            val dir = File(context.cacheDir, "reports").apply { mkdirs() }
            val file = File(dir, "customers_due_report_${System.currentTimeMillis()}.csv")
            FileWriter(file).use { writer ->
                writer.append("Customer Name,Phone,Address,Opening Balance,Current Due\n")
                for (c in customers) {
                    writer.append("\"${c.name.replace("\"", "\"\"")}\",")
                    writer.append("\"${c.phone}\",")
                    writer.append("\"${c.address.replace("\"", "\"\"")}\",")
                    writer.append("${c.openingBalance},")
                    writer.append("${c.currentDue}\n")
                }
            }
            file
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun exportExpensesCsv(context: Context, expenses: List<Expense>): File? {
        return try {
            val dir = File(context.cacheDir, "reports").apply { mkdirs() }
            val file = File(dir, "expenses_report_${System.currentTimeMillis()}.csv")
            FileWriter(file).use { writer ->
                writer.append("Date,Category,Amount,Payment Method,Notes\n")
                for (e in expenses) {
                    writer.append("\"${Formatters.formatDateTime(e.date)}\",")
                    writer.append("\"${e.category}\",")
                    writer.append("${e.amount},")
                    writer.append("\"${e.paymentMethod}\",")
                    writer.append("\"${e.notes.replace("\"", "\"\"")}\"\n")
                }
            }
            file
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun shareCsv(context: Context, file: File, title: String = "Share Report CSV") {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, file.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, title))
    }
}
