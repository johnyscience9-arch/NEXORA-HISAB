package com.example.util

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import androidx.room.withTransaction
import com.example.data.local.AppDatabase
import com.example.data.model.*
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileWriter

object BackupManager {

    suspend fun createJsonBackup(context: Context, db: AppDatabase): File? {
        return try {
            val root = JSONObject()
            root.put("app", "NEXORA_HISAB")
            root.put("version", 1)
            root.put("timestamp", System.currentTimeMillis())
            root.put("exportDate", Formatters.formatDateTime(System.currentTimeMillis()))

            // Customers
            val customers = db.customerDao().getAllCustomers().first()
            val customersArr = JSONArray()
            for (c in customers) {
                val obj = JSONObject()
                obj.put("id", c.id)
                obj.put("name", c.name)
                obj.put("phone", c.phone)
                obj.put("address", c.address)
                obj.put("openingBalance", c.openingBalance)
                obj.put("currentDue", c.currentDue)
                obj.put("createdAt", c.createdAt)
                customersArr.put(obj)
            }
            root.put("customers", customersArr)

            // Suppliers
            val suppliers = db.supplierDao().getAllSuppliers().first()
            val suppliersArr = JSONArray()
            for (s in suppliers) {
                val obj = JSONObject()
                obj.put("id", s.id)
                obj.put("name", s.name)
                obj.put("phone", s.phone)
                obj.put("address", s.address)
                obj.put("openingBalance", s.openingBalance)
                obj.put("currentPayable", s.currentPayable)
                obj.put("createdAt", s.createdAt)
                suppliersArr.put(obj)
            }
            root.put("suppliers", suppliersArr)

            // Products
            val products = db.productDao().getAllProducts().first()
            val productsArr = JSONArray()
            for (p in products) {
                val obj = JSONObject()
                obj.put("id", p.id)
                obj.put("name", p.name)
                obj.put("code", p.code)
                obj.put("category", p.category)
                obj.put("purchasePrice", p.purchasePrice)
                obj.put("sellingPrice", p.sellingPrice)
                obj.put("stockQuantity", p.stockQuantity)
                obj.put("unit", p.unit)
                obj.put("lowStockAlert", p.lowStockAlert)
                obj.put("createdAt", p.createdAt)
                productsArr.put(obj)
            }
            root.put("products", productsArr)

            // Categories
            val categories = db.categoryDao().getAllCategories().first()
            val categoriesArr = JSONArray()
            for (cat in categories) {
                val obj = JSONObject()
                obj.put("id", cat.id)
                obj.put("name", cat.name)
                categoriesArr.put(obj)
            }
            root.put("categories", categoriesArr)

            // Accounts
            val accounts = db.accountDao().getAllAccounts().first()
            val accountsArr = JSONArray()
            for (a in accounts) {
                val obj = JSONObject()
                obj.put("id", a.id)
                obj.put("name", a.name)
                obj.put("accountType", a.accountType)
                obj.put("accountNumber", a.accountNumber)
                obj.put("balance", a.balance)
                obj.put("createdAt", a.createdAt)
                accountsArr.put(obj)
            }
            root.put("accounts", accountsArr)

            // Sales
            val sales = db.saleDao().getAllSales().first()
            val salesArr = JSONArray()
            for (sale in sales) {
                val obj = JSONObject()
                obj.put("id", sale.id)
                obj.put("invoiceNumber", sale.invoiceNumber)
                obj.put("customerId", sale.customerId ?: 0L)
                obj.put("customerName", sale.customerName)
                obj.put("customerPhone", sale.customerPhone)
                obj.put("subtotal", sale.subtotal)
                obj.put("discount", sale.discount)
                obj.put("grandTotal", sale.grandTotal)
                obj.put("paidAmount", sale.paidAmount)
                obj.put("dueAmount", sale.dueAmount)
                obj.put("paymentMethod", sale.paymentMethod)
                obj.put("accountId", sale.accountId ?: 1L)
                obj.put("status", sale.status)
                obj.put("date", sale.date)
                obj.put("notes", sale.notes)

                val items = db.saleDao().getSaleItemsList(sale.id)
                val itemsArr = JSONArray()
                for (item in items) {
                    val itmObj = JSONObject()
                    itmObj.put("id", item.id)
                    itmObj.put("productId", item.productId)
                    itmObj.put("productName", item.productName)
                    itmObj.put("productCode", item.productCode)
                    itmObj.put("quantity", item.quantity)
                    itmObj.put("unitPrice", item.unitPrice)
                    itmObj.put("purchasePriceAtSale", item.purchasePriceAtSale)
                    itmObj.put("total", item.total)
                    itemsArr.put(itmObj)
                }
                obj.put("items", itemsArr)
                salesArr.put(obj)
            }
            root.put("sales", salesArr)

            // Purchases
            val purchases = db.purchaseDao().getAllPurchases().first()
            val purchasesArr = JSONArray()
            for (p in purchases) {
                val obj = JSONObject()
                obj.put("id", p.id)
                obj.put("invoiceNumber", p.invoiceNumber)
                obj.put("supplierId", p.supplierId ?: 0L)
                obj.put("supplierName", p.supplierName)
                obj.put("supplierPhone", p.supplierPhone)
                obj.put("subtotal", p.subtotal)
                obj.put("grandTotal", p.grandTotal)
                obj.put("paidAmount", p.paidAmount)
                obj.put("remainingPayable", p.remainingPayable)
                obj.put("paymentMethod", p.paymentMethod)
                obj.put("accountId", p.accountId ?: 1L)
                obj.put("date", p.date)
                obj.put("notes", p.notes)

                val items = db.purchaseDao().getPurchaseItemsList(p.id)
                val itemsArr = JSONArray()
                for (item in items) {
                    val itmObj = JSONObject()
                    itmObj.put("id", item.id)
                    itmObj.put("productId", item.productId)
                    itmObj.put("productName", item.productName)
                    itmObj.put("quantity", item.quantity)
                    itmObj.put("unitPrice", item.unitPrice)
                    itmObj.put("total", item.total)
                    itemsArr.put(itmObj)
                }
                obj.put("items", itemsArr)
                purchasesArr.put(obj)
            }
            root.put("purchases", purchasesArr)

            // Expenses
            val expenses = db.expenseDao().getAllExpenses().first()
            val expensesArr = JSONArray()
            for (e in expenses) {
                val obj = JSONObject()
                obj.put("id", e.id)
                obj.put("category", e.category)
                obj.put("amount", e.amount)
                obj.put("paymentMethod", e.paymentMethod)
                obj.put("accountId", e.accountId)
                obj.put("date", e.date)
                obj.put("notes", e.notes)
                expensesArr.put(obj)
            }
            root.put("expenses", expensesArr)

            // Payments
            val payments = db.paymentDao().getAllPayments().first()
            val paymentsArr = JSONArray()
            for (pm in payments) {
                val obj = JSONObject()
                obj.put("id", pm.id)
                obj.put("partyType", pm.partyType)
                obj.put("partyId", pm.partyId)
                obj.put("partyName", pm.partyName)
                obj.put("amount", pm.amount)
                obj.put("paymentMethod", pm.paymentMethod)
                obj.put("accountId", pm.accountId)
                obj.put("referenceNumber", pm.referenceNumber)
                obj.put("date", pm.date)
                obj.put("notes", pm.notes)
                paymentsArr.put(obj)
            }
            root.put("payments", paymentsArr)

            // Save to backups folder
            val backupDir = File(context.cacheDir, "backups").apply { mkdirs() }
            val backupFile = File(backupDir, "NEXORA_BACKUP_${System.currentTimeMillis()}.json")
            FileWriter(backupFile).use { writer ->
                writer.write(root.toString(2))
            }
            backupFile
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    suspend fun restoreFromJson(db: AppDatabase, jsonString: String): Boolean = db.withTransaction {
        try {
            val root = JSONObject(jsonString)
            if (root.optString("app") != "NEXORA_HISAB") {
                return@withTransaction false
            }

            // Restore Customers
            if (root.has("customers")) {
                val arr = root.getJSONArray("customers")
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val customer = Customer(
                        id = obj.optLong("id", 0L),
                        name = obj.getString("name"),
                        phone = obj.optString("phone", ""),
                        address = obj.optString("address", ""),
                        openingBalance = obj.optDouble("openingBalance", 0.0),
                        currentDue = obj.optDouble("currentDue", 0.0),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                    )
                    db.customerDao().insertCustomer(customer)
                }
            }

            // Restore Suppliers
            if (root.has("suppliers")) {
                val arr = root.getJSONArray("suppliers")
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val supplier = Supplier(
                        id = obj.optLong("id", 0L),
                        name = obj.getString("name"),
                        phone = obj.optString("phone", ""),
                        address = obj.optString("address", ""),
                        openingBalance = obj.optDouble("openingBalance", 0.0),
                        currentPayable = obj.optDouble("currentPayable", 0.0),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                    )
                    db.supplierDao().insertSupplier(supplier)
                }
            }

            // Restore Products
            if (root.has("products")) {
                val arr = root.getJSONArray("products")
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val product = Product(
                        id = obj.optLong("id", 0L),
                        name = obj.getString("name"),
                        code = obj.optString("code", ""),
                        category = obj.optString("category", "General"),
                        purchasePrice = obj.optDouble("purchasePrice", 0.0),
                        sellingPrice = obj.optDouble("sellingPrice", 0.0),
                        stockQuantity = obj.optDouble("stockQuantity", 0.0),
                        unit = obj.optString("unit", "pcs"),
                        lowStockAlert = obj.optDouble("lowStockAlert", 5.0),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                    )
                    db.productDao().insertProduct(product)
                }
            }

            // Restore Accounts
            if (root.has("accounts")) {
                val arr = root.getJSONArray("accounts")
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val account = Account(
                        id = obj.optLong("id", 0L),
                        name = obj.getString("name"),
                        accountType = obj.optString("accountType", "CASH"),
                        accountNumber = obj.optString("accountNumber", ""),
                        balance = obj.optDouble("balance", 0.0),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                    )
                    db.accountDao().insertAccount(account)
                }
            }

            // Restore Expenses
            if (root.has("expenses")) {
                val arr = root.getJSONArray("expenses")
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val expense = Expense(
                        id = obj.optLong("id", 0L),
                        category = obj.getString("category"),
                        amount = obj.getDouble("amount"),
                        paymentMethod = obj.optString("paymentMethod", "CASH"),
                        accountId = obj.optLong("accountId", 1L),
                        date = obj.optLong("date", System.currentTimeMillis()),
                        notes = obj.optString("notes", "")
                    )
                    db.expenseDao().insertExpense(expense)
                }
            }

            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun shareBackup(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, file.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share Database Backup"))
    }
}
