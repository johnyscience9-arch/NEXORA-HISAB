package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.data.model.Sale
import com.example.data.model.SaleItem
import java.io.File
import java.io.FileOutputStream

object PdfInvoiceGenerator {

    fun generateAndShareInvoice(
        context: Context,
        sale: Sale,
        items: List<SaleItem>,
        businessName: String,
        businessPhone: String,
        businessAddress: String,
        invoiceNote: String,
        currency: AppCurrency
    ): File? {
        try {
            val pdfDocument = PdfDocument()
            val pageWidth = 595 // A4 standard width in points at 72 dpi
            val pageHeight = 842 // A4 standard height
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            val paint = Paint().apply { isAntiAlias = true }

            // 1. Header background
            paint.color = Color.rgb(13, 21, 39) // Nexora dark header
            canvas.drawRect(0f, 0f, pageWidth.toFloat(), 130f, paint)

            // Header Title
            paint.color = Color.WHITE
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textSize = 22f
            canvas.drawText(businessName.ifBlank { "NEXORA ENTERPRISE" }, 36f, 50f, paint)

            // Business details
            paint.typeface = Typeface.DEFAULT
            paint.textSize = 10f
            paint.color = Color.rgb(200, 215, 235)
            if (businessPhone.isNotBlank()) canvas.drawText("Phone: $businessPhone", 36f, 72f, paint)
            if (businessAddress.isNotBlank()) canvas.drawText("Address: $businessAddress", 36f, 88f, paint)

            // Invoice Tag on Right
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textSize = 20f
            paint.color = Color.rgb(0, 229, 255) // Cyan
            canvas.drawText("TAX INVOICE", (pageWidth - 160).toFloat(), 50f, paint)

            paint.typeface = Typeface.DEFAULT
            paint.textSize = 10f
            paint.color = Color.WHITE
            canvas.drawText("Invoice #: ${sale.invoiceNumber}", (pageWidth - 160).toFloat(), 72f, paint)
            canvas.drawText("Date: ${Formatters.formatDateTime(sale.date)}", (pageWidth - 160).toFloat(), 88f, paint)
            canvas.drawText("Status: ${sale.status}", (pageWidth - 160).toFloat(), 104f, paint)

            // 2. Bill To Card
            paint.color = Color.rgb(245, 247, 250)
            canvas.drawRect(36f, 150f, (pageWidth - 36).toFloat(), 215f, paint)

            paint.color = Color.rgb(20, 30, 50)
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textSize = 12f
            canvas.drawText("BILL TO / CUSTOMER:", 48f, 172f, paint)

            paint.typeface = Typeface.DEFAULT
            paint.textSize = 11f
            paint.color = Color.rgb(40, 50, 70)
            canvas.drawText("Name: ${sale.customerName}", 48f, 192f, paint)
            if (sale.customerPhone.isNotBlank()) {
                canvas.drawText("Phone: ${sale.customerPhone}", 300f, 192f, paint)
            }

            // 3. Table Header
            val tableTop = 235f
            paint.color = Color.rgb(30, 41, 59)
            canvas.drawRect(36f, tableTop, (pageWidth - 36).toFloat(), tableTop + 25f, paint)

            paint.color = Color.WHITE
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textSize = 10f
            canvas.drawText("#", 45f, tableTop + 16f, paint)
            canvas.drawText("ITEM DESCRIPTION", 75f, tableTop + 16f, paint)
            canvas.drawText("QTY", 320f, tableTop + 16f, paint)
            canvas.drawText("RATE (${currency.symbol})", 380f, tableTop + 16f, paint)
            canvas.drawText("TOTAL (${currency.symbol})", 470f, tableTop + 16f, paint)

            // 4. Table Rows
            var currentY = tableTop + 45f
            paint.typeface = Typeface.DEFAULT
            paint.textSize = 10f

            items.forEachIndexed { index, item ->
                paint.color = if (index % 2 == 0) Color.rgb(255, 255, 255) else Color.rgb(248, 250, 252)
                canvas.drawRect(36f, currentY - 14f, (pageWidth - 36).toFloat(), currentY + 8f, paint)

                paint.color = Color.rgb(30, 41, 59)
                canvas.drawText("${index + 1}", 45f, currentY, paint)
                canvas.drawText(item.productName, 75f, currentY, paint)
                canvas.drawText("${item.quantity}", 320f, currentY, paint)
                canvas.drawText("%.2f".format(item.unitPrice), 380f, currentY, paint)
                canvas.drawText("%.2f".format(item.total), 470f, currentY, paint)

                currentY += 24f
            }

            // Divider line
            paint.color = Color.rgb(220, 225, 230)
            paint.strokeWidth = 1.5f
            canvas.drawLine(36f, currentY, (pageWidth - 36).toFloat(), currentY, paint)
            currentY += 20f

            // 5. Totals on Right
            val totalsX = (pageWidth - 220).toFloat()
            paint.typeface = Typeface.DEFAULT
            paint.textSize = 10f
            paint.color = Color.rgb(50, 60, 80)

            canvas.drawText("Subtotal:", totalsX, currentY, paint)
            canvas.drawText("${currency.symbol} %.2f".format(sale.subtotal), totalsX + 110f, currentY, paint)
            currentY += 18f

            if (sale.discount > 0) {
                canvas.drawText("Discount:", totalsX, currentY, paint)
                canvas.drawText("- ${currency.symbol} %.2f".format(sale.discount), totalsX + 110f, currentY, paint)
                currentY += 18f
            }

            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textSize = 12f
            paint.color = Color.rgb(13, 21, 39)
            canvas.drawText("Grand Total:", totalsX, currentY, paint)
            canvas.drawText("${currency.symbol} %.2f".format(sale.grandTotal), totalsX + 110f, currentY, paint)
            currentY += 20f

            paint.typeface = Typeface.DEFAULT
            paint.textSize = 10f
            paint.color = Color.rgb(0, 150, 80)
            canvas.drawText("Paid Amount:", totalsX, currentY, paint)
            canvas.drawText("${currency.symbol} %.2f".format(sale.paidAmount), totalsX + 110f, currentY, paint)
            currentY += 18f

            if (sale.dueAmount > 0) {
                paint.color = Color.rgb(200, 30, 30)
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                canvas.drawText("Due Balance:", totalsX, currentY, paint)
                canvas.drawText("${currency.symbol} %.2f".format(sale.dueAmount), totalsX + 110f, currentY, paint)
                currentY += 20f
            }

            // 6. Footer Note
            val footerY = (pageHeight - 60).toFloat()
            paint.typeface = Typeface.DEFAULT
            paint.textSize = 9f
            paint.color = Color.rgb(120, 130, 145)
            canvas.drawText(invoiceNote.ifBlank { "Generated by Nexora Hisab. Thank you for your business!" }, 36f, footerY, paint)
            canvas.drawText("Payment Method: ${sale.paymentMethod}  |  Payment status is updated in real-time.", 36f, footerY + 16f, paint)

            pdfDocument.finishPage(page)

            // Save to internal cache
            val invoicesDir = File(context.cacheDir, "invoices").apply { mkdirs() }
            val invoiceFile = File(invoicesDir, "Invoice_${sale.invoiceNumber}.pdf")
            val outputStream = FileOutputStream(invoiceFile)
            pdfDocument.writeTo(outputStream)
            outputStream.flush()
            outputStream.close()
            pdfDocument.close()

            return invoiceFile
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    fun sharePdf(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, file.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share Invoice PDF"))
    }
}
