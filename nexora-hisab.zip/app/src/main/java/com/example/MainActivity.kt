package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.NexoraViewModel
import com.example.util.AppCurrency
import com.example.util.AppLanguage
import com.example.util.Localization

sealed class AppScreen {
    object Dashboard : AppScreen()
    object Sales : AppScreen()
    object CreateSale : AppScreen()
    object Purchases : AppScreen()
    object CreatePurchase : AppScreen()
    object Inventory : AppScreen()
    object Parties : AppScreen()
    object Expenses : AppScreen()
    object CashBank : AppScreen()
    object Reports : AppScreen()
    object Settings : AppScreen()
}

class MainActivity : ComponentActivity() {

    private val viewModel: NexoraViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            NexoraTheme {
                val isUnlocked by viewModel.isAppUnlocked.collectAsStateWithLifecycle()
                val language by viewModel.language.collectAsStateWithLifecycle()
                val currency by viewModel.currency.collectAsStateWithLifecycle()
                val businessProfile by viewModel.businessProfile.collectAsStateWithLifecycle()
                val isPinEnabled by viewModel.isPinEnabled.collectAsStateWithLifecycle()
                val allowNegativeStock by viewModel.allowNegativeStock.collectAsStateWithLifecycle()

                val metrics by viewModel.dashboardMetrics.collectAsStateWithLifecycle()
                val recentTransactions by viewModel.recentTransactions.collectAsStateWithLifecycle()

                var currentScreen by remember { mutableStateOf<AppScreen>(AppScreen.Dashboard) }
                var showMoreSheet by remember { mutableStateOf(false) }

                if (!isUnlocked) {
                    PinLockScreen(
                        language = language,
                        onUnlock = { pin -> viewModel.unlockApp(pin) }
                    )
                } else {
                    // Back handler for sub-screens
                    if (currentScreen != AppScreen.Dashboard) {
                        BackHandler {
                            currentScreen = when (currentScreen) {
                                AppScreen.CreateSale -> AppScreen.Sales
                                AppScreen.CreatePurchase -> AppScreen.Purchases
                                else -> AppScreen.Dashboard
                            }
                        }
                    }

                    Scaffold(
                        containerColor = NexoraDarkBackground,
                        bottomBar = {
                            // Only show bottom navigation on primary screens
                            val isPrimaryScreen = currentScreen in listOf(
                                AppScreen.Dashboard,
                                AppScreen.Sales,
                                AppScreen.Purchases,
                                AppScreen.Inventory,
                                AppScreen.Parties
                            )

                            if (isPrimaryScreen) {
                                NavigationBar(
                                    containerColor = NexoraDarkSurface,
                                    contentColor = NexoraCyanPrimary,
                                    windowInsets = WindowInsets.navigationBars,
                                    modifier = Modifier.testTag("main_bottom_nav_bar")
                                ) {
                                    NavigationBarItem(
                                        selected = currentScreen == AppScreen.Dashboard,
                                        onClick = { currentScreen = AppScreen.Dashboard },
                                        icon = { Icon(Icons.Default.Dashboard, contentDescription = null) },
                                        label = { Text(Localization.getString("dashboard", language), fontSize = 10.sp) },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = Color.Black,
                                            indicatorColor = NexoraCyanPrimary,
                                            unselectedIconColor = NexoraTextSecondary,
                                            unselectedTextColor = NexoraTextSecondary
                                        ),
                                        modifier = Modifier.testTag("nav_dashboard")
                                    )
                                    NavigationBarItem(
                                        selected = currentScreen == AppScreen.Sales,
                                        onClick = { currentScreen = AppScreen.Sales },
                                        icon = { Icon(Icons.Default.PointOfSale, contentDescription = null) },
                                        label = { Text(Localization.getString("sales", language), fontSize = 10.sp) },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = Color.Black,
                                            indicatorColor = NexoraCyanPrimary,
                                            unselectedIconColor = NexoraTextSecondary,
                                            unselectedTextColor = NexoraTextSecondary
                                        ),
                                        modifier = Modifier.testTag("nav_sales")
                                    )
                                    NavigationBarItem(
                                        selected = currentScreen == AppScreen.Purchases,
                                        onClick = { currentScreen = AppScreen.Purchases },
                                        icon = { Icon(Icons.Default.Inventory2, contentDescription = null) },
                                        label = { Text(Localization.getString("purchases", language), fontSize = 10.sp) },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = Color.Black,
                                            indicatorColor = NexoraTealAccent,
                                            unselectedIconColor = NexoraTextSecondary,
                                            unselectedTextColor = NexoraTextSecondary
                                        ),
                                        modifier = Modifier.testTag("nav_purchases")
                                    )
                                    NavigationBarItem(
                                        selected = currentScreen == AppScreen.Inventory,
                                        onClick = { currentScreen = AppScreen.Inventory },
                                        icon = { Icon(Icons.Default.Warehouse, contentDescription = null) },
                                        label = { Text(Localization.getString("inventory", language), fontSize = 10.sp) },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = Color.Black,
                                            indicatorColor = NexoraGoldAmber,
                                            unselectedIconColor = NexoraTextSecondary,
                                            unselectedTextColor = NexoraTextSecondary
                                        ),
                                        modifier = Modifier.testTag("nav_inventory")
                                    )
                                    NavigationBarItem(
                                        selected = currentScreen == AppScreen.Parties,
                                        onClick = { currentScreen = AppScreen.Parties },
                                        icon = { Icon(Icons.Default.People, contentDescription = null) },
                                        label = { Text(Localization.getString("parties", language), fontSize = 10.sp) },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = Color.Black,
                                            indicatorColor = NexoraCyanPrimary,
                                            unselectedIconColor = NexoraTextSecondary,
                                            unselectedTextColor = NexoraTextSecondary
                                        ),
                                        modifier = Modifier.testTag("nav_parties")
                                    )
                                    NavigationBarItem(
                                        selected = false,
                                        onClick = { showMoreSheet = true },
                                        icon = { Icon(Icons.Default.Menu, contentDescription = null) },
                                        label = { Text("More", fontSize = 10.sp) },
                                        colors = NavigationBarItemDefaults.colors(
                                            unselectedIconColor = NexoraTextSecondary,
                                            unselectedTextColor = NexoraTextSecondary
                                        ),
                                        modifier = Modifier.testTag("nav_more")
                                    )
                                }
                            }
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            AnimatedContent(
                                targetState = currentScreen,
                                label = "ScreenTransition"
                            ) { screen ->
                                when (screen) {
                                    is AppScreen.Dashboard -> {
                                        DashboardScreen(
                                            metrics = metrics,
                                            currency = currency,
                                            language = language,
                                            businessName = businessProfile.name,
                                            recentTransactions = recentTransactions,
                                            onNavigateToCreateSale = { currentScreen = AppScreen.CreateSale },
                                            onNavigateToCreatePurchase = { currentScreen = AppScreen.CreatePurchase },
                                            onNavigateToParties = { currentScreen = AppScreen.Parties },
                                            onNavigateToExpenses = { currentScreen = AppScreen.Expenses },
                                            onNavigateToReports = { currentScreen = AppScreen.Reports },
                                            onToggleCurrency = {
                                                val next = if (currency == AppCurrency.BDT) AppCurrency.USD else AppCurrency.BDT
                                                viewModel.setCurrency(next)
                                            },
                                            onToggleLanguage = {
                                                val next = if (language == AppLanguage.BENGALI) AppLanguage.ENGLISH else AppLanguage.BENGALI
                                                viewModel.setLanguage(next)
                                            }
                                        )
                                    }
                                    is AppScreen.Sales -> {
                                        SalesScreen(
                                            viewModel = viewModel,
                                            currency = currency,
                                            language = language,
                                            businessProfile = businessProfile,
                                            onNavigateToCreateSale = { currentScreen = AppScreen.CreateSale }
                                        )
                                    }
                                    is AppScreen.CreateSale -> {
                                        CreateSaleScreen(
                                            viewModel = viewModel,
                                            currency = currency,
                                            language = language,
                                            onNavigateBack = { currentScreen = AppScreen.Sales }
                                        )
                                    }
                                    is AppScreen.Purchases -> {
                                        PurchasesScreen(
                                            viewModel = viewModel,
                                            currency = currency,
                                            language = language,
                                            onNavigateToCreatePurchase = { currentScreen = AppScreen.CreatePurchase }
                                        )
                                    }
                                    is AppScreen.CreatePurchase -> {
                                        CreatePurchaseScreen(
                                            viewModel = viewModel,
                                            currency = currency,
                                            language = language,
                                            onNavigateBack = { currentScreen = AppScreen.Purchases }
                                        )
                                    }
                                    is AppScreen.Inventory -> {
                                        InventoryScreen(
                                            viewModel = viewModel,
                                            currency = currency,
                                            language = language
                                        )
                                    }
                                    is AppScreen.Parties -> {
                                        PartiesScreen(
                                            viewModel = viewModel,
                                            currency = currency,
                                            language = language
                                        )
                                    }
                                    is AppScreen.Expenses -> {
                                        ExpensesScreen(
                                            viewModel = viewModel,
                                            currency = currency,
                                            language = language
                                        )
                                    }
                                    is AppScreen.CashBank -> {
                                        CashBankScreen(
                                            viewModel = viewModel,
                                            currency = currency,
                                            language = language
                                        )
                                    }
                                    is AppScreen.Reports -> {
                                        ReportsScreen(
                                            viewModel = viewModel,
                                            currency = currency,
                                            language = language
                                        )
                                    }
                                    is AppScreen.Settings -> {
                                        SettingsScreen(
                                            viewModel = viewModel,
                                            currency = currency,
                                            language = language,
                                            businessProfile = businessProfile,
                                            isPinEnabled = isPinEnabled,
                                            allowNegativeStock = allowNegativeStock
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // "More" Bottom Sheet for secondary menus
                    if (showMoreSheet) {
                        ModalBottomSheet(
                            onDismissRequest = { showMoreSheet = false },
                            containerColor = NexoraDarkSurfaceVariant,
                            dragHandle = { BottomSheetDefaults.DragHandle(color = NexoraDarkBorder) }
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 20.dp)
                                    .padding(bottom = 36.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = "Accounting Modules",
                                    color = NexoraTextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))

                                MoreSheetItem(
                                    title = Localization.getString("expenses", language),
                                    subtitle = "Record & track business operating expenses",
                                    icon = Icons.Default.ReceiptLong,
                                    accent = NexoraGoldAmber,
                                    onClick = {
                                        currentScreen = AppScreen.Expenses
                                        showMoreSheet = false
                                    }
                                )

                                MoreSheetItem(
                                    title = Localization.getString("cash_bank", language),
                                    subtitle = "Cash & bank accounts, deposit & withdrawals",
                                    icon = Icons.Default.AccountBalance,
                                    accent = NexoraEmeraldSuccess,
                                    onClick = {
                                        currentScreen = AppScreen.CashBank
                                        showMoreSheet = false
                                    }
                                )

                                MoreSheetItem(
                                    title = Localization.getString("reports", language),
                                    subtitle = "P&L, COGS, Cash Flow, CSV & PDF export",
                                    icon = Icons.Default.Assessment,
                                    accent = NexoraCyanPrimary,
                                    onClick = {
                                        currentScreen = AppScreen.Reports
                                        showMoreSheet = false
                                    }
                                )

                                MoreSheetItem(
                                    title = Localization.getString("settings", language),
                                    subtitle = "Security PIN, Language, Currency, Backup & Restore",
                                    icon = Icons.Default.Settings,
                                    accent = NexoraTealAccent,
                                    onClick = {
                                        currentScreen = AppScreen.Settings
                                        showMoreSheet = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MoreSheetItem(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = NexoraDarkSurface,
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NexoraDarkBorder)),
        modifier = Modifier.fillMaxWidth().testTag("more_menu_${title.lowercase().replace(" ", "_")}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(accent.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = accent, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, color = NexoraTextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(text = subtitle, color = NexoraTextSecondary, fontSize = 11.sp)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = NexoraTextMuted)
        }
    }
}
