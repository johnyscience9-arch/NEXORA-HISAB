# NEXORA HISAB — Native Android Accounting & Inventory Management System

**NEXORA HISAB** is a commercial-grade, native Android accounting and inventory management application engineered with Kotlin, Jetpack Compose, Material 3, and an offline-first Room Database architecture.

---

## 🌟 Key Features

### 1. Modern Dark Dashboard
- **Real-Time Financial Figures**:
  - Total Sales, Purchases, Expenses, Gross & Net Profit
  - Cash in Hand, Bank Balance, Customer Due, Supplier Payable, and Total Stock Valuation
- **Periodic Summaries**: Daily, Weekly, and Monthly financial breakdowns
- **Quick Action Bar**: Instant shortcuts to New Sale, New Purchase, Receive Money, Pay Supplier, and New Expense
- **Live Transaction Ledger**: Reactive feed of all cash, bank, invoice, and payment movements

### 2. Accurate Accounting & Profit Calculation
- **Cost of Goods Sold (COGS)**: Profit is computed using real cost tracking per item (`Net Profit = (Sales - COGS) - Expenses`), adhering to standard accounting principles.
- **Double-Entry Balance Updates**: Atomic Room transactions ensure customer dues, supplier payables, inventory stock, and cash/bank accounts are adjusted simultaneously without discrepancy.

### 3. Sales & Printable Invoices
- **Invoice Creation**: Multi-item product selector, live inventory stock indicators, discount deductions, subtotal, and grand total.
- **Payment Handling**: Full paid, partial paid, or full due options with automated ledger posting.
- **Native PDF Invoices**: Generates A4 PDF tax invoices with company details, itemized table, and payment breakdown via Android's native `PdfDocument` and shareable through Android `FileProvider`.
- **Cancellation Protection**: Safe invoice cancellation with automatic stock restoration and balance reversal.

### 4. Inventory & Stock Control
- Product code (SKU), category, cost price, selling price, stock quantity, and unit.
- Low-stock visual warning badges and custom alert thresholds.
- Negative stock protection (toggleable in Settings).
- Total stock valuation metrics (cost value vs. potential retail revenue).

### 5. Customer & Supplier Ledgers
- Complete contact records with opening balances and live running balances.
- **Customer Dues**: Receive full or partial payments; auto-updates customer due and posts to cash/bank accounts.
- **Supplier Payables**: Record payments with cheque/reference tracking; auto-updates payable balances.
- **Statements**: Party-wise transaction history (sales, purchases, payments).

### 6. Expense Management
- Categorized business operating expenses (Rent, Salary, Utilities, Marketing, Transport, etc.).
- Daily and monthly expense summaries.
- Automatic deduction from chosen Cash or Bank account.

### 7. Cash & Bank Management
- Multi-account management (Cash in Hand and Bank Accounts).
- Deposit cash to bank and withdraw cash from bank.
- Account-to-account transfer with transaction ledger.

### 8. Multi-Format Reports & Analytics
- Profit & Loss Statement (Gross Sales, COGS, Gross Profit, Expenses, Net Profit).
- Customer Due Report & Supplier Payable Report.
- Inventory Valuation Report.
- **Export Formats**: One-tap export to CSV and PDF sharing.

### 9. Multi-Language & Multi-Currency
- **Dual Language**: Bengali (বাংলা) and English (EN) with live in-app switching.
- **Multi-Currency**: Bangladeshi Taka (BDT ৳) and US Dollar (USD $) with high-precision decimal formatting.

### 10. Security & Data Protection
- **App PIN Lock**: Secure 4-digit PIN with SHA-256 cryptographic hashing.
- **Offline-First Storage**: 100% offline functionality powered by Room SQLite; no external server dependency required.
- **JSON Backup & Restore**: Complete database snapshot export to JSON and safe restore with confirmation safeguards.

---

## 🛠️ Technology Stack

- **Platform**: Native Android (Min SDK 24 / Android 7.0+, Target SDK 36)
- **Language**: Kotlin 2.2+
- **UI Framework**: Jetpack Compose with Material Design 3 (M3)
- **Architecture**: MVVM (Model-View-ViewModel) + Repository Pattern
- **Persistence**: Room Database (KSP) + Kotlin Coroutines & Flow
- **Preferences**: Jetpack DataStore Preferences
- **Document Generation**: Native Android `PdfDocument` & standard CSV writer
- **Asset Sharing**: Android `FileProvider` (zero sensitive permissions required)

---

## 🚀 Build Instructions

### Prerequisites
- Android Studio Ladybug / Meerkat or later
- JDK 17 or JDK 21

### Building Debug APK
To build an installable Debug APK:
```bash
gradle assembleDebug
```
The resulting APK will be generated at:
`app/build/outputs/apk/debug/app-debug.apk`

### Building Release APK
To build a signed Release APK:
```bash
gradle assembleRelease
```
The resulting APK will be generated at:
`app/build/outputs/apk/release/app-release.apk`

### Running Unit Tests
```bash
gradle :app:testDebugUnitTest
```

---

## 📄 License & Distribution
Developed as part of the **NEXORA Commercial Suite**. Ready for production deployment and Google Play distribution.
